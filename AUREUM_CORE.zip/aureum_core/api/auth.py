"""
AUREUM CORE — Authentication & Authorisation
JWT-based identity verification with role-based access control.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Annotated

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel

from aureum_core.utils.config import get_config

_config = get_config()
_bearer = HTTPBearer(auto_error=True)


class TokenPayload(BaseModel):
    sub: str          # subject (user/system identifier)
    role: str         # e.g. "operator", "admin", "readonly"
    exp: datetime
    iat: datetime


# ── Simulated credential store (replace with DB in production) ─────────────────
_CREDENTIAL_STORE: dict[str, dict] = {
    "admin": {"password": "aureum_admin_2024", "role": "admin"},
    "operator": {"password": "aureum_op_2024", "role": "operator"},
    "readonly": {"password": "aureum_ro_2024", "role": "readonly"},
}


def issue_token(username: str, password: str) -> str:
    """Validate credentials and issue a signed JWT."""
    user = _CREDENTIAL_STORE.get(username)
    if not user or user["password"] != password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )

    now = datetime.now(timezone.utc)
    payload = {
        "sub": username,
        "role": user["role"],
        "iat": now,
        "exp": now + timedelta(minutes=_config.JWT_EXPIRY_MINUTES),
    }
    return jwt.encode(payload, _config.JWT_SECRET_KEY, algorithm=_config.JWT_ALGORITHM)


def _decode_token(token: str) -> TokenPayload:
    """Decode and validate a JWT, returning its payload."""
    try:
        raw = jwt.decode(
            token,
            _config.JWT_SECRET_KEY,
            algorithms=[_config.JWT_ALGORITHM],
        )
        return TokenPayload(**raw)
    except JWTError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid or expired token: {exc}",
            headers={"WWW-Authenticate": "Bearer"},
        )


async def require_authenticated(
    credentials: Annotated[HTTPAuthorizationCredentials, Security(_bearer)]
) -> TokenPayload:
    """FastAPI dependency: validates JWT and returns the token payload."""
    return _decode_token(credentials.credentials)


async def require_operator(
    token: Annotated[TokenPayload, Depends(require_authenticated)]
) -> TokenPayload:
    """Require operator or admin role."""
    if token.role not in ("operator", "admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Role '{token.role}' is not authorised for this operation",
        )
    return token


async def require_admin(
    token: Annotated[TokenPayload, Depends(require_authenticated)]
) -> TokenPayload:
    """Require admin role exclusively."""
    if token.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrator role required",
        )
    return token

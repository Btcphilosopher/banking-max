"""
AUREUM CORE — API Schema Definitions
Pydantic request/response models for the FastAPI layer.
"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, Field, field_validator

from aureum_core.ledger.accounts import AccountType
from aureum_core.ledger.transactions import TransactionStatus


# ── Request Schemas ────────────────────────────────────────────────────────────

class CreateAccountSchema(BaseModel):
    owner_id: str = Field(..., min_length=1, max_length=128)
    account_type: AccountType
    currency: str = Field(..., min_length=3, max_length=3)
    name: str = Field(..., min_length=1, max_length=256)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("currency")
    @classmethod
    def normalise(cls, v: str) -> str:
        return v.upper()


class TransferSchema(BaseModel):
    source_account_id: str = Field(..., description="Debtor account UUID")
    destination_account_id: str = Field(..., description="Creditor account UUID")
    amount: Decimal = Field(..., gt=Decimal("0.01"))
    currency: str = Field(..., min_length=3, max_length=3)
    reference: str | None = Field(None, max_length=256)
    idempotency_key: str | None = Field(None, max_length=256)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("currency")
    @classmethod
    def normalise(cls, v: str) -> str:
        return v.upper()


class TokenRequestSchema(BaseModel):
    username: str
    password: str


# ── Response Schemas ───────────────────────────────────────────────────────────

class AccountResponse(BaseModel):
    id: str
    owner_id: str
    account_type: str
    currency: str
    name: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class BalanceResponse(BaseModel):
    account_id: str
    currency: str
    total_debits: Decimal
    total_credits: Decimal
    balance: Decimal


class TransactionResponse(BaseModel):
    transaction_id: str
    status: str
    entry_count: int
    total_amount: Decimal
    currency: str
    committed_at: datetime | None
    reference: str | None
    message: str


class LedgerEntryResponse(BaseModel):
    id: str
    transaction_id: str
    account_id: str
    direction: str
    amount: Decimal
    currency: str
    sequence: int
    posted_at: datetime


class TransactionDetailResponse(BaseModel):
    transaction_id: str
    status: str
    transaction_type: str
    reference: str | None
    initiated_by: str
    initiated_at: datetime
    committed_at: datetime | None
    entries: list[LedgerEntryResponse]


class ReconciliationResponse(BaseModel):
    run_at: str
    transactions_checked: int
    balanced_transactions: int
    unbalanced_count: int
    unbalanced_transactions: list[dict]
    total_system_debit: str
    total_system_credit: str
    system_imbalance: str
    is_consistent: bool


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class ErrorResponse(BaseModel):
    error: str
    detail: str | None = None
    violations: list[str] = Field(default_factory=list)

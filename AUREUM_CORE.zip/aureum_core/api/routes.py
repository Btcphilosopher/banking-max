"""
AUREUM CORE — API Route Definitions
FastAPI endpoint implementations for the banking kernel.

Endpoints:
    POST /auth/token
    POST /accounts/create
    GET  /accounts/{account_id}
    POST /transactions/transfer
    GET  /transactions/{transaction_id}
    GET  /balances/{account_id}
    GET  /ledger/{account_id}/entries
    GET  /admin/reconciliation
    GET  /health
"""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.api.auth import (
    TokenPayload,
    issue_token,
    require_admin,
    require_authenticated,
    require_operator,
)
from aureum_core.api.schemas import (
    AccountResponse,
    BalanceResponse,
    CreateAccountSchema,
    LedgerEntryResponse,
    ReconciliationResponse,
    TokenRequestSchema,
    TokenResponse,
    TransactionDetailResponse,
    TransactionResponse,
    TransferSchema,
)
from aureum_core.audit.reconciliation import ReconciliationEngine
from aureum_core.ledger.accounts import CreateAccountRequest
from aureum_core.ledger.ledger_engine import AccountNotFoundError, LedgerEngine
from aureum_core.ledger.transactions import TransferRequest
from aureum_core.storage.database import AccountRecord, TransactionRecord, get_session
from aureum_core.transactions.processor import TransactionCommitEngine, TransactionRejectedError

router = APIRouter()

# ── Type aliases ──────────────────────────────────────────────────────────────
DBSession = Annotated[AsyncSession, Depends(get_session)]
AuthToken = Annotated[TokenPayload, Depends(require_authenticated)]
OperatorToken = Annotated[TokenPayload, Depends(require_operator)]
AdminToken = Annotated[TokenPayload, Depends(require_admin)]


# ── Health ────────────────────────────────────────────────────────────────────

@router.get("/health", tags=["System"])
async def health_check() -> dict:
    """Liveness probe — confirms the API is operational."""
    return {"status": "OPERATIONAL", "system": "AUREUM CORE"}


# ── Authentication ─────────────────────────────────────────────────────────────

@router.post("/auth/token", response_model=TokenResponse, tags=["Authentication"])
async def obtain_token(body: TokenRequestSchema) -> TokenResponse:
    """Issue a JWT access token for the given credentials."""
    from aureum_core.utils.config import get_config
    config = get_config()
    token = issue_token(body.username, body.password)
    return TokenResponse(
        access_token=token,
        expires_in=config.JWT_EXPIRY_MINUTES * 60,
    )


# ── Accounts ──────────────────────────────────────────────────────────────────

@router.post(
    "/accounts/create",
    response_model=AccountResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Accounts"],
)
async def create_account(
    body: CreateAccountSchema,
    db: DBSession,
    token: OperatorToken,
) -> AccountResponse:
    """
    Provision a new account in the ledger.
    Requires operator or admin role.
    """
    engine = LedgerEngine(db)
    request = CreateAccountRequest(
        owner_id=body.owner_id,
        account_type=body.account_type,
        currency=body.currency,
        name=body.name,
        metadata=body.metadata,
    )
    account = await engine.provision_account(request)
    return AccountResponse(
        id=account.id,
        owner_id=account.owner_id,
        account_type=account.account_type.value,
        currency=account.currency,
        name=account.name,
        is_active=account.is_active,
        created_at=account.created_at,
    )


@router.get("/accounts/{account_id}", response_model=AccountResponse, tags=["Accounts"])
async def get_account(
    account_id: str,
    db: DBSession,
    token: AuthToken,
) -> AccountResponse:
    """Retrieve account details by identifier."""
    engine = LedgerEngine(db)
    try:
        account = await engine.fetch_account(account_id)
    except AccountNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))

    return AccountResponse(
        id=account.id,
        owner_id=account.owner_id,
        account_type=account.account_type.value,
        currency=account.currency,
        name=account.name,
        is_active=account.is_active,
        created_at=account.created_at,
    )


# ── Balances ──────────────────────────────────────────────────────────────────

@router.get("/balances/{account_id}", response_model=BalanceResponse, tags=["Balances"])
async def get_balance(
    account_id: str,
    db: DBSession,
    token: AuthToken,
) -> BalanceResponse:
    """
    Return the computed balance for an account.
    Balance is always derived from the live ledger — never from a stored field.
    """
    engine = LedgerEngine(db)
    try:
        await engine.fetch_account(account_id)  # validates existence
        balance = await engine.compute_balance(account_id)
    except AccountNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))

    return BalanceResponse(
        account_id=balance.account_id,
        currency=balance.currency,
        total_debits=balance.total_debits,
        total_credits=balance.total_credits,
        balance=balance.balance,
    )


# ── Transactions ──────────────────────────────────────────────────────────────

@router.post(
    "/transactions/transfer",
    response_model=TransactionResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Transactions"],
)
async def execute_transfer(
    body: TransferSchema,
    request: Request,
    db: DBSession,
    token: OperatorToken,
) -> TransactionResponse:
    """
    Execute a double-entry transfer between two accounts.
    Runs the full AUREUM transaction pipeline:
    Validate → Risk Screen → Ledger Commit → Audit → Response
    """
    engine = TransactionCommitEngine(db)
    transfer_request = TransferRequest(
        source_account_id=body.source_account_id,
        destination_account_id=body.destination_account_id,
        amount=body.amount,
        currency=body.currency,
        reference=body.reference,
        idempotency_key=body.idempotency_key,
        initiated_by=token.sub,
        metadata={**body.metadata, "ip_address": request.client.host if request.client else None},
    )

    try:
        result = await engine.execute_transfer(transfer_request)
    except TransactionRejectedError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": str(exc), "violations": exc.violations},
        )
    except AccountNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal processing error: {exc}",
        )

    return TransactionResponse(
        transaction_id=result.transaction_id,
        status=result.status.value,
        entry_count=result.entry_count,
        total_amount=result.total_amount,
        currency=result.currency,
        committed_at=result.committed_at,
        reference=result.reference,
        message=result.message,
    )


@router.get(
    "/transactions/{transaction_id}",
    response_model=TransactionDetailResponse,
    tags=["Transactions"],
)
async def get_transaction(
    transaction_id: str,
    db: DBSession,
    token: AuthToken,
) -> TransactionDetailResponse:
    """Retrieve a transaction and its full ledger entry set."""
    from sqlalchemy import select
    stmt = select(TransactionRecord).where(TransactionRecord.id == transaction_id)
    result = await db.execute(stmt)
    record = result.scalar_one_or_none()

    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Transaction {transaction_id!r} not found",
        )

    engine = LedgerEngine(db)
    entries = await engine.get_transaction_entries(transaction_id)

    return TransactionDetailResponse(
        transaction_id=record.id,
        status=record.status,
        transaction_type=record.transaction_type,
        reference=record.reference,
        initiated_by=record.initiated_by,
        initiated_at=record.initiated_at,
        committed_at=record.committed_at,
        entries=[
            LedgerEntryResponse(
                id=e.id,
                transaction_id=e.transaction_id,
                account_id=e.account_id,
                direction=e.direction.value,
                amount=e.amount,
                currency=e.currency,
                sequence=e.sequence,
                posted_at=e.posted_at,
            )
            for e in entries
        ],
    )


# ── Ledger ────────────────────────────────────────────────────────────────────

@router.get(
    "/ledger/{account_id}/entries",
    response_model=list[LedgerEntryResponse],
    tags=["Ledger"],
)
async def get_account_ledger(
    account_id: str,
    db: DBSession,
    token: AuthToken,
    limit: int = 50,
    offset: int = 0,
) -> list[LedgerEntryResponse]:
    """
    Return the ledger entry history for an account.
    Results are ordered by posting timestamp (most recent first).
    """
    engine = LedgerEngine(db)
    try:
        await engine.fetch_account(account_id)
    except AccountNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))

    entries = await engine.get_account_entries(account_id, limit=min(limit, 500), offset=offset)
    return [
        LedgerEntryResponse(
            id=e.id,
            transaction_id=e.transaction_id,
            account_id=e.account_id,
            direction=e.direction.value,
            amount=e.amount,
            currency=e.currency,
            sequence=e.sequence,
            posted_at=e.posted_at,
        )
        for e in entries
    ]


# ── Administration ────────────────────────────────────────────────────────────

@router.get(
    "/admin/reconciliation",
    response_model=ReconciliationResponse,
    tags=["Administration"],
)
async def run_reconciliation(
    db: DBSession,
    token: AdminToken,
) -> ReconciliationResponse:
    """
    Execute a full ledger reconciliation pass.
    Admin role required.
    """
    engine = ReconciliationEngine(db)
    report = await engine.run_full_reconciliation()
    data = report.to_dict()
    return ReconciliationResponse(
        run_at=data["run_at"],
        transactions_checked=data["transactions_checked"],
        balanced_transactions=data["balanced_transactions"],
        unbalanced_count=data["unbalanced_count"],
        unbalanced_transactions=data["unbalanced_transactions"],
        total_system_debit=data["total_system_debit"],
        total_system_credit=data["total_system_credit"],
        system_imbalance=data["system_imbalance"],
        is_consistent=data["is_consistent"],
    )

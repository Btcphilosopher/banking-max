"""
AUREUM CORE — Payment Gateway
Abstract payment rail selector and dispatch controller.
Determines the optimal rail for each payment instruction.
"""
from __future__ import annotations

from decimal import Decimal
from enum import Enum

from aureum_core.payments.rails.faster_payments import FasterPaymentsRail
from aureum_core.payments.rails.sepa import SEPARail
from aureum_core.payments.rails.swift import SWIFTRail
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("payment_gateway")


class PaymentRailIdentifier(str, Enum):
    FASTER_PAYMENTS = "FASTER_PAYMENTS"
    SEPA = "SEPA"
    SWIFT = "SWIFT"
    INTERNAL = "INTERNAL"


class PaymentGateway:
    """
    Intelligent payment rail selector.
    Evaluates eligibility criteria to route each payment through the
    optimal scheme — prioritising speed and cost efficiency.

    Rail selection priority:
        1. INTERNAL  — same-institution transfers (zero latency)
        2. FASTER_PAYMENTS — domestic GBP (near-instant)
        3. SEPA       — EUR within SEPA zone (instant or T+1)
        4. SWIFT      — all other cross-border payments (T+2)
    """

    def __init__(self) -> None:
        self._fps = FasterPaymentsRail()
        self._sepa = SEPARail()
        self._swift = SWIFTRail()

    def select_rail(
        self,
        amount: Decimal,
        currency: str,
        is_internal: bool = False,
        destination_country: str = "GB",
    ) -> PaymentRailIdentifier:
        """Select the most appropriate payment rail for the given parameters."""
        if is_internal:
            return PaymentRailIdentifier.INTERNAL

        if self._fps.is_eligible(amount, currency) and destination_country == "GB":
            return PaymentRailIdentifier.FASTER_PAYMENTS

        if self._sepa.is_eligible(amount, currency):
            return PaymentRailIdentifier.SEPA

        return PaymentRailIdentifier.SWIFT

    async def dispatch(
        self,
        payment_id: str,
        amount: Decimal,
        currency: str,
        rail: PaymentRailIdentifier,
    ) -> dict:
        """Dispatch a payment instruction to the selected rail."""
        _log.audit_event(
            "PAYMENT_DISPATCHED",
            actor="SYSTEM",
            details={
                "payment_id": payment_id,
                "rail": rail.value,
                "amount": str(amount),
                "currency": currency,
            },
        )

        if rail == PaymentRailIdentifier.FASTER_PAYMENTS:
            return await self._fps.submit(payment_id, amount, currency)
        elif rail == PaymentRailIdentifier.SEPA:
            return await self._sepa.submit(payment_id, amount, currency)
        elif rail == PaymentRailIdentifier.SWIFT:
            return await self._swift.submit(payment_id, amount, currency)
        else:
            # INTERNAL — immediate settlement, no external submission
            from datetime import datetime, timezone
            return {
                "scheme": "INTERNAL",
                "payment_id": payment_id,
                "status": "SETTLED",
                "expected_settlement_at": datetime.now(timezone.utc),
            }

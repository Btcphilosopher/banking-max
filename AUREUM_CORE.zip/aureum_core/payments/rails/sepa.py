"""
AUREUM CORE — SEPA Payment Rail
Single Euro Payments Area scheme abstraction.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal

from aureum_core.utils.config import get_config
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("sepa")
_config = get_config()


class SEPARail:
    """
    SEPA Credit Transfer (SCT) and SEPA Instant (SCT Inst) rail abstraction.
    Covers EUR payments within the SEPA zone.
    """

    SCHEME_NAME = "SEPA"
    SUPPORTED_CURRENCIES = frozenset({"EUR"})
    MAX_AMOUNT_EUR = Decimal("999_999_999.99")
    INSTANT_MAX_EUR = Decimal("100_000.00")

    def is_eligible(self, amount: Decimal, currency: str) -> bool:
        return currency.upper() in self.SUPPORTED_CURRENCIES

    def is_instant_eligible(self, amount: Decimal) -> bool:
        return amount <= self.INSTANT_MAX_EUR

    def get_expected_settlement_time(self, amount: Decimal) -> datetime:
        if self.is_instant_eligible(amount):
            return datetime.now(timezone.utc) + timedelta(seconds=10)
        # Standard SCT: next business day
        return datetime.now(timezone.utc) + timedelta(days=_config.SEPA_SETTLEMENT_DAYS)

    async def submit(self, payment_id: str, amount: Decimal, currency: str) -> dict:
        """Submit a payment to the simulated SEPA scheme."""
        is_instant = self.is_instant_eligible(amount)
        settlement_time = self.get_expected_settlement_time(amount)

        _log.audit_event(
            "SEPA_PAYMENT_SUBMITTED",
            actor="SYSTEM",
            details={
                "payment_id": payment_id,
                "amount": str(amount),
                "currency": currency,
                "instant": is_instant,
                "expected_settlement": settlement_time.isoformat(),
            },
        )
        return {
            "scheme": self.SCHEME_NAME,
            "payment_id": payment_id,
            "status": "SUBMITTED",
            "instant": is_instant,
            "expected_settlement_at": settlement_time,
        }

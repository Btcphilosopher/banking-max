"""
AUREUM CORE — SWIFT Payment Rail
Society for Worldwide Interbank Financial Telecommunication abstraction.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal

from aureum_core.utils.config import get_config
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("swift")
_config = get_config()


class SWIFTRail:
    """
    SWIFT GPI (Global Payments Innovation) international wire transfer rail.
    Supports multi-currency cross-border payments with correspondent banking.
    """

    SCHEME_NAME = "SWIFT"
    MIN_AMOUNT = Decimal("1.00")

    def is_eligible(self, amount: Decimal, currency: str) -> bool:
        """SWIFT supports any currency above minimum threshold."""
        return amount >= self.MIN_AMOUNT

    def get_expected_settlement_time(self) -> datetime:
        """Standard SWIFT settlement: T+2 business days."""
        return datetime.now(timezone.utc) + timedelta(days=_config.SWIFT_SETTLEMENT_DAYS)

    async def submit(
        self,
        payment_id: str,
        amount: Decimal,
        currency: str,
        debtor_bic: str = "AUREUMXXXX",
        creditor_bic: str = "UNKNOWN",
    ) -> dict:
        """Submit an international wire via the simulated SWIFT GPI network."""
        settlement_time = self.get_expected_settlement_time()
        uetr = _generate_uetr()

        _log.audit_event(
            "SWIFT_PAYMENT_SUBMITTED",
            actor="SYSTEM",
            details={
                "payment_id": payment_id,
                "uetr": uetr,
                "amount": str(amount),
                "currency": currency,
                "debtor_bic": debtor_bic,
                "creditor_bic": creditor_bic,
                "expected_settlement": settlement_time.isoformat(),
            },
        )
        return {
            "scheme": self.SCHEME_NAME,
            "payment_id": payment_id,
            "uetr": uetr,
            "status": "SUBMITTED",
            "expected_settlement_at": settlement_time,
        }


def _generate_uetr() -> str:
    """Generate a SWIFT UETR (Unique End-to-end Transaction Reference)."""
    import uuid
    return str(uuid.uuid4())

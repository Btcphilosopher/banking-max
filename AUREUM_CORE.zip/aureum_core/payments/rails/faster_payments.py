"""
AUREUM CORE — Faster Payments Rail
UK domestic real-time payment scheme abstraction.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal

from aureum_core.utils.config import get_config
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("faster_payments")
_config = get_config()


class FasterPaymentsRail:
    """
    UK Faster Payments Service (FPS) abstraction.
    Near-instant settlement for domestic GBP transfers up to £1,000,000.
    """

    SCHEME_NAME = "FASTER_PAYMENTS"
    SUPPORTED_CURRENCIES = frozenset({"GBP"})
    MAX_AMOUNT_GBP = Decimal("1_000_000.00")
    SETTLEMENT_LATENCY_SECONDS = 2  # Simulated

    def is_eligible(self, amount: Decimal, currency: str) -> bool:
        return (
            currency.upper() in self.SUPPORTED_CURRENCIES
            and amount <= self.MAX_AMOUNT_GBP
        )

    def get_expected_settlement_time(self) -> datetime:
        return datetime.now(timezone.utc) + timedelta(seconds=self.SETTLEMENT_LATENCY_SECONDS)

    async def submit(self, payment_id: str, amount: Decimal, currency: str) -> dict:
        """Submit a payment to the simulated FPS scheme."""
        settlement_time = self.get_expected_settlement_time()
        _log.audit_event(
            "FPS_PAYMENT_SUBMITTED",
            actor="SYSTEM",
            details={
                "payment_id": payment_id,
                "amount": str(amount),
                "currency": currency,
                "expected_settlement": settlement_time.isoformat(),
            },
        )
        return {
            "scheme": self.SCHEME_NAME,
            "payment_id": payment_id,
            "status": "SUBMITTED",
            "expected_settlement_at": settlement_time,
        }

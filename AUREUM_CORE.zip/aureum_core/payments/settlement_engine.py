"""
AUREUM CORE — Settlement Engine
Asynchronous payment settlement and ledger reconciliation controller.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.payments.payment_gateway import PaymentGateway, PaymentRailIdentifier
from aureum_core.storage.database import PaymentRecord
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("settlement_engine")


class SettlementEngine:
    """
    Manages the full lifecycle of payment settlement:
        QUEUED → SUBMITTED → SETTLED | FAILED

    Integrates with the PaymentGateway for rail dispatch and
    updates the PaymentRecord upon settlement confirmation.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._gateway = PaymentGateway()

    async def initiate_payment(
        self,
        transaction_id: str,
        debtor_account_id: str,
        creditor_account_id: str,
        amount: Decimal,
        currency: str,
        is_internal: bool = True,
        destination_country: str = "GB",
    ) -> PaymentRecord:
        """
        Initiate a payment instruction and dispatch to the appropriate rail.
        Creates a PaymentRecord and submits to the gateway.
        """
        payment_id = f"PAY-{str(uuid.uuid4())[:12].upper()}"

        rail = self._gateway.select_rail(
            amount=amount,
            currency=currency,
            is_internal=is_internal,
            destination_country=destination_country,
        )

        dispatch_result = await self._gateway.dispatch(
            payment_id=payment_id,
            amount=amount,
            currency=currency,
            rail=rail,
        )

        # Determine initial status from dispatch result
        initial_status = dispatch_result.get("status", "SUBMITTED")
        settled_at = None
        if initial_status == "SETTLED":
            settled_at = datetime.now(timezone.utc)

        record = PaymentRecord(
            id=payment_id,
            transaction_id=transaction_id,
            rail=rail.value,
            status=initial_status,
            amount=amount,
            currency=currency,
            debtor_account_id=debtor_account_id,
            creditor_account_id=creditor_account_id,
            expected_settlement_at=dispatch_result.get("expected_settlement_at"),
            settled_at=settled_at,
            metadata_={
                "uetr": dispatch_result.get("uetr"),
                "instant": dispatch_result.get("instant", False),
                "dispatch_result": {
                    k: str(v) if not isinstance(v, (str, bool, type(None))) else v
                    for k, v in dispatch_result.items()
                },
            },
        )
        self._session.add(record)
        await self._session.flush()

        _log.audit_event(
            "PAYMENT_INITIATED",
            actor="SYSTEM",
            details={
                "payment_id": payment_id,
                "transaction_id": transaction_id,
                "rail": rail.value,
                "status": initial_status,
                "amount": str(amount),
                "currency": currency,
            },
        )
        return record

    async def confirm_settlement(self, payment_id: str) -> PaymentRecord:
        """Mark a payment as settled (called by settlement callback/polling)."""
        stmt = select(PaymentRecord).where(PaymentRecord.id == payment_id)
        result = await self._session.execute(stmt)
        record = result.scalar_one_or_none()

        if record is None:
            raise ValueError(f"Payment {payment_id!r} not found")

        record.status = "SETTLED"
        record.settled_at = datetime.now(timezone.utc)
        await self._session.flush()

        _log.audit_event(
            "PAYMENT_SETTLED",
            actor="SYSTEM",
            details={"payment_id": payment_id},
        )
        return record

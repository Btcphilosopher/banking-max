"""
AUREUM CORE — Foreign Exchange Engine
Simulated real-time FX conversion with gain/loss tracking.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import ClassVar

from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.currency.currency_models import quantise_amount
from aureum_core.storage.database import FXRateRecord
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("fx_engine")

# ── Simulated mid-market rates against GBP ────────────────────────────────────
_BASE_RATES_VS_GBP: dict[str, Decimal] = {
    "GBP": Decimal("1.0000"),
    "USD": Decimal("1.2650"),
    "EUR": Decimal("1.1720"),
    "CHF": Decimal("1.1450"),
    "JPY": Decimal("188.50"),
    "CAD": Decimal("1.7210"),
    "AUD": Decimal("1.9380"),
    "SGD": Decimal("1.7050"),
    "HKD": Decimal("9.8750"),
    "NOK": Decimal("13.420"),
    "SEK": Decimal("13.850"),
    "DKK": Decimal("8.7310"),
}

_SPREAD_BPS = Decimal("25")  # 25 basis points spread


@dataclass(frozen=True)
class FXQuote:
    """A point-in-time FX conversion quotation."""
    base_currency: str
    quote_currency: str
    mid_rate: Decimal
    bid_rate: Decimal
    offer_rate: Decimal
    quoted_at: datetime
    source: str = "AUREUM_SIMULATED"

    @property
    def spread_bps(self) -> Decimal:
        return ((self.offer_rate - self.bid_rate) / self.mid_rate * 10000).quantize(Decimal("0.01"))


@dataclass(frozen=True)
class FXConversionResult:
    """Result of an FX conversion operation."""
    source_amount: Decimal
    source_currency: str
    converted_amount: Decimal
    target_currency: str
    applied_rate: Decimal
    fx_gain_loss: Decimal
    quote: FXQuote


class FXEngine:
    """
    Foreign exchange conversion engine with spread modelling and gain/loss accounting.
    Rates are simulated with realistic micro-volatility for development/testing.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    def get_live_quote(self, base_currency: str, quote_currency: str) -> FXQuote:
        """
        Generate a live FX quote with simulated micro-volatility.
        In production, this would call an external rate feed (Bloomberg, Reuters, etc.)
        """
        base = base_currency.upper()
        quote = quote_currency.upper()

        if base == quote:
            mid = Decimal("1.0")
            return FXQuote(
                base_currency=base,
                quote_currency=quote,
                mid_rate=mid,
                bid_rate=mid,
                offer_rate=mid,
                quoted_at=datetime.now(timezone.utc),
            )
        else:
            base_vs_gbp = _BASE_RATES_VS_GBP.get(base)
            quote_vs_gbp = _BASE_RATES_VS_GBP.get(quote)

            if base_vs_gbp is None or quote_vs_gbp is None:
                raise ValueError(f"Unsupported currency pair: {base}/{quote}")

            mid = (quote_vs_gbp / base_vs_gbp).quantize(Decimal("0.000001"))

            # Apply micro-volatility: ±0.05%
            volatility = Decimal(str(1 + (random.uniform(-0.0005, 0.0005))))
            mid = (mid * volatility).quantize(Decimal("0.000001"))

            spread_factor = _SPREAD_BPS / Decimal("20000")
            bid = (mid * (1 - spread_factor)).quantize(Decimal("0.000001"))
            offer = (mid * (1 + spread_factor)).quantize(Decimal("0.000001"))

            return FXQuote(
                base_currency=base,
                quote_currency=quote,
                mid_rate=mid,
                bid_rate=bid,
                offer_rate=offer,
                quoted_at=datetime.now(timezone.utc),
            )

    async def convert(
        self,
        amount: Decimal,
        source_currency: str,
        target_currency: str,
        book_rate: Decimal | None = None,
    ) -> FXConversionResult:
        """
        Convert an amount from source to target currency.
        Uses offer rate for buy (institution sells foreign currency).
        """
        source = source_currency.upper()
        target = target_currency.upper()

        quote = self.get_live_quote(source, target)
        applied_rate = book_rate if book_rate is not None else quote.offer_rate

        converted = (amount * applied_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        converted = quantise_amount(converted, target)

        # FX gain/loss vs mid: positive = gain for institution
        mid_converted = (amount * quote.mid_rate).quantize(Decimal("0.01"))
        fx_gain_loss = converted - mid_converted

        # Persist rate snapshot
        rate_record = FXRateRecord(
            base_currency=source,
            quote_currency=target,
            rate=applied_rate,
            source=quote.source,
        )
        self._session.add(rate_record)

        _log.audit_event(
            "FX_CONVERSION",
            actor="SYSTEM",
            details={
                "amount": str(amount),
                "source": source,
                "target": target,
                "rate": str(applied_rate),
                "converted": str(converted),
            },
        )

        return FXConversionResult(
            source_amount=amount,
            source_currency=source,
            converted_amount=converted,
            target_currency=target,
            applied_rate=applied_rate,
            fx_gain_loss=fx_gain_loss,
            quote=quote,
        )

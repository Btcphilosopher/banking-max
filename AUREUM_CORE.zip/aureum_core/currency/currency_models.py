"""
AUREUM CORE — Currency Domain Models
ISO 4217 currency definitions and monetary precision standards.
"""
from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import ClassVar


class CurrencyCode(str, Enum):
    """Supported ISO 4217 currency codes within AUREUM CORE."""
    GBP = "GBP"
    USD = "USD"
    EUR = "EUR"
    CHF = "CHF"
    JPY = "JPY"
    CAD = "CAD"
    AUD = "AUD"
    SGD = "SGD"
    HKD = "HKD"
    NOK = "NOK"
    SEK = "SEK"
    DKK = "DKK"


CURRENCY_PRECISION: dict[str, int] = {
    "GBP": 2, "USD": 2, "EUR": 2, "CHF": 2,
    "CAD": 2, "AUD": 2, "SGD": 2, "HKD": 2,
    "NOK": 2, "SEK": 2, "DKK": 2,
    "JPY": 0,  # Zero decimal places
}

CURRENCY_NAMES: dict[str, str] = {
    "GBP": "Pound Sterling",
    "USD": "United States Dollar",
    "EUR": "Euro",
    "CHF": "Swiss Franc",
    "JPY": "Japanese Yen",
    "CAD": "Canadian Dollar",
    "AUD": "Australian Dollar",
    "SGD": "Singapore Dollar",
    "HKD": "Hong Kong Dollar",
    "NOK": "Norwegian Krone",
    "SEK": "Swedish Krona",
    "DKK": "Danish Krone",
}


def quantise_amount(amount: Decimal, currency: str) -> Decimal:
    """Round amount to the correct decimal precision for the given currency."""
    precision = CURRENCY_PRECISION.get(currency.upper(), 2)
    quantiser = Decimal(10) ** -precision
    return amount.quantize(quantiser)


def is_supported_currency(currency: str) -> bool:
    """Return True if the currency is within the AUREUM supported set."""
    return currency.upper() in CURRENCY_PRECISION

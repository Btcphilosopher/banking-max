"""
AUREUM CORE — Account Domain Models
Structural definitions for capital ownership units within the ledger.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class AccountType(str, Enum):
    """
    Chart of accounts classification per double-entry convention.
    Normal balance polarity:
        Asset / Expense    → Debit increases balance
        Liability / Equity / Revenue → Credit increases balance
    """
    ASSET = "asset"
    LIABILITY = "liability"
    EQUITY = "equity"
    REVENUE = "revenue"
    EXPENSE = "expense"

    @property
    def normal_balance(self) -> str:
        """Return the direction that increases this account type's balance."""
        if self in (AccountType.ASSET, AccountType.EXPENSE):
            return "debit"
        return "credit"


class Account(BaseModel):
    """
    Immutable account descriptor. Balances are never stored here —
    they are always derived from the ledger entry set.
    """
    model_config = {"frozen": True}

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    owner_id: str = Field(..., description="Identity of the account owner")
    account_type: AccountType
    currency: str = Field(..., min_length=3, max_length=3)
    name: str = Field(..., min_length=1, max_length=256)
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("currency")
    @classmethod
    def normalise_currency(cls, v: str) -> str:
        return v.upper()


class AccountBalance(BaseModel):
    """Derived balance view — computed from ledger entries, never persisted."""
    model_config = {"frozen": True}

    account_id: str
    currency: str
    total_debits: Decimal
    total_credits: Decimal
    balance: Decimal

    @classmethod
    def compute(
        cls,
        account_id: str,
        currency: str,
        total_debits: Decimal,
        total_credits: Decimal,
    ) -> "AccountBalance":
        return cls(
            account_id=account_id,
            currency=currency,
            total_debits=total_debits,
            total_credits=total_credits,
            balance=total_debits - total_credits,
        )


class CreateAccountRequest(BaseModel):
    """Validated request envelope for account provisioning."""
    owner_id: str = Field(..., min_length=1, max_length=128)
    account_type: AccountType
    currency: str = Field(..., min_length=3, max_length=3)
    name: str = Field(..., min_length=1, max_length=256)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("currency")
    @classmethod
    def normalise_currency(cls, v: str) -> str:
        return v.upper()

"""
AUREUM CORE — Ledger Entry Domain Models
The atomic unit of the double-entry accounting system.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class EntryDirection(str, Enum):
    """
    Directional polarity of a ledger entry.
    Effect on account balance depends on account type normal balance.
    """
    DEBIT = "debit"
    CREDIT = "credit"

    @property
    def opposite(self) -> "EntryDirection":
        return EntryDirection.CREDIT if self == EntryDirection.DEBIT else EntryDirection.DEBIT


class LedgerEntry(BaseModel):
    """
    Immutable double-entry ledger record.
    Once committed, a ledger entry is eternal.
    """
    model_config = {"frozen": True}

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    transaction_id: str = Field(..., description="Parent transaction identifier")
    account_id: str = Field(..., description="Target account identifier")
    direction: EntryDirection
    amount: Decimal = Field(..., gt=Decimal("0"), description="Absolute value — always positive")
    currency: str = Field(..., min_length=3, max_length=3)
    sequence: int = Field(..., ge=0, description="Monotonic ordering sequence")
    posted_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("currency")
    @classmethod
    def normalise_currency(cls, v: str) -> str:
        return v.upper()

    @field_validator("amount")
    @classmethod
    def validate_precision(cls, v: Decimal) -> Decimal:
        """Enforce maximum 10 decimal places of precision."""
        return v.quantize(Decimal("0.0000000001"))


class EntryPair(BaseModel):
    """
    Canonical double-entry pair: one debit, one credit.
    Used as the minimal valid ledger transaction unit.
    """
    model_config = {"frozen": True}

    debit: LedgerEntry
    credit: LedgerEntry

    @model_validator(mode="after")
    def validate_balance(self) -> "EntryPair":
        if self.debit.amount != self.credit.amount:
            raise ValueError(
                f"LEDGER INVARIANT VIOLATION: debit {self.debit.amount} ≠ credit {self.credit.amount}"
            )
        if self.debit.direction != EntryDirection.DEBIT:
            raise ValueError("First entry must be DEBIT direction")
        if self.credit.direction != EntryDirection.CREDIT:
            raise ValueError("Second entry must be CREDIT direction")
        return self


class EntrySet(BaseModel):
    """
    Validated collection of ledger entries constituting a complete transaction.
    Enforces the fundamental accounting identity: Σ(debits) = Σ(credits)
    """
    model_config = {"frozen": True}

    entries: tuple[LedgerEntry, ...]

    @model_validator(mode="after")
    def validate_double_entry_balance(self) -> "EntrySet":
        if len(self.entries) < 2:
            raise ValueError(
                "LEDGER INVARIANT VIOLATION: minimum two entries required per transaction"
            )

        total_debits = sum(
            e.amount for e in self.entries if e.direction == EntryDirection.DEBIT
        )
        total_credits = sum(
            e.amount for e in self.entries if e.direction == EntryDirection.CREDIT
        )

        if total_debits != total_credits:
            raise ValueError(
                f"LEDGER INVARIANT VIOLATION: Σ(debits)={total_debits} ≠ Σ(credits)={total_credits}. "
                "Transaction is unbalanced and cannot be committed."
            )
        return self

    @property
    def total_debits(self) -> Decimal:
        return sum(e.amount for e in self.entries if e.direction == EntryDirection.DEBIT)

    @property
    def total_credits(self) -> Decimal:
        return sum(e.amount for e in self.entries if e.direction == EntryDirection.CREDIT)

    @property
    def is_balanced(self) -> bool:
        return self.total_debits == self.total_credits

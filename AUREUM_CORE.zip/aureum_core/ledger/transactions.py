"""
AUREUM CORE — Transaction Domain Models
The immutable envelope of financial intent.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, model_validator

from aureum_core.ledger.entries import EntrySet, LedgerEntry


class TransactionStatus(str, Enum):
    PENDING = "PENDING"
    COMMITTED = "COMMITTED"
    REJECTED = "REJECTED"
    ROLLED_BACK = "ROLLED_BACK"


class TransactionType(str, Enum):
    INTERNAL_TRANSFER = "INTERNAL_TRANSFER"
    PAYMENT_OUTBOUND = "PAYMENT_OUTBOUND"
    PAYMENT_INBOUND = "PAYMENT_INBOUND"
    FX_CONVERSION = "FX_CONVERSION"
    FEE_CHARGE = "FEE_CHARGE"
    INTEREST_CREDIT = "INTEREST_CREDIT"
    ADJUSTMENT = "ADJUSTMENT"
    SETTLEMENT = "SETTLEMENT"


class Transaction(BaseModel):
    """
    Sovereign transaction record.
    Immutable once committed — status transitions are the only permitted mutations.
    """
    model_config = {"frozen": True}

    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:16].upper())
    idempotency_key: str | None = None
    status: TransactionStatus = TransactionStatus.PENDING
    transaction_type: TransactionType
    entry_set: EntrySet
    reference: str | None = None
    initiated_by: str = Field(..., description="Actor/system that initiated the transaction")
    initiated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    committed_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    def with_status(self, status: TransactionStatus, committed_at: datetime | None = None) -> "Transaction":
        """Return a new Transaction with updated status (immutable pattern)."""
        data = self.model_dump()
        data["status"] = status
        if committed_at:
            data["committed_at"] = committed_at
        return Transaction(**data)


class TransferRequest(BaseModel):
    """
    Validated wire transfer instruction from the API or internal systems.
    """
    source_account_id: str = Field(..., description="Debtor account")
    destination_account_id: str = Field(..., description="Creditor account")
    amount: Decimal = Field(..., gt=Decimal("0.01"))
    currency: str = Field(..., min_length=3, max_length=3)
    reference: str | None = Field(None, max_length=256)
    idempotency_key: str | None = Field(None, max_length=256)
    initiated_by: str = Field(..., min_length=1, max_length=128)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_accounts_differ(self) -> "TransferRequest":
        if self.source_account_id == self.destination_account_id:
            raise ValueError("Source and destination accounts must differ")
        return self


class TransactionResult(BaseModel):
    """The response envelope returned after transaction processing."""
    model_config = {"frozen": True}

    transaction_id: str
    status: TransactionStatus
    entry_count: int
    total_amount: Decimal
    currency: str
    committed_at: datetime | None
    reference: str | None
    message: str

"""
AUREUM CORE — Ledger Engine
The sovereign accounting kernel. All financial state derives from this engine.

Doctrine:
    Transaction Request → Validation → Ledger Commit → Audit Log → Response

Financial Invariants:
    1. Every transaction must balance:  Σ(debits) = Σ(credits)
    2. Ledger is append-only:           no UPDATE or DELETE on ledger_entries
    3. Balances are derived:            never stored, always computed from entries
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Sequence

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.ledger.accounts import Account, AccountBalance, AccountType, CreateAccountRequest
from aureum_core.ledger.entries import EntryDirection, EntrySet, LedgerEntry
from aureum_core.ledger.transactions import (
    Transaction,
    TransactionResult,
    TransactionStatus,
    TransactionType,
    TransferRequest,
)
from aureum_core.storage.database import AccountRecord, LedgerEntryRecord, TransactionRecord
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("ledger_engine")


class LedgerInvariantError(Exception):
    """Raised when a fundamental ledger invariant is violated."""


class AccountNotFoundError(Exception):
    """Raised when a referenced account cannot be located."""


class InsufficientFundsError(Exception):
    """Raised when a debit would render an asset account insolvent."""


class LedgerEngine:
    """
    The authoritative double-entry ledger kernel.

    All monetary state within AUREUM CORE is derived from the
    append-only entry set maintained by this engine.
    No external component may bypass the LedgerEngine to mutate balances.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    # ── Account Operations ─────────────────────────────────────────────────────

    async def provision_account(self, request: CreateAccountRequest) -> Account:
        """
        Provision a new account in the ledger.
        Accounts are the ownership units of capital; they carry no balance state.
        """
        account = Account(
            owner_id=request.owner_id,
            account_type=request.account_type,
            currency=request.currency,
            name=request.name,
            metadata=request.metadata,
        )

        record = AccountRecord(
            id=account.id,
            owner_id=account.owner_id,
            account_type=account.account_type.value,
            currency=account.currency,
            name=account.name,
            is_active=account.is_active,
            metadata_=account.metadata,
        )
        self._session.add(record)
        await self._session.flush()

        _log.audit_event(
            "ACCOUNT_PROVISIONED",
            actor=request.owner_id,
            details={"account_id": account.id, "currency": account.currency},
        )
        return account

    async def fetch_account(self, account_id: str) -> Account:
        """Retrieve an account by its identifier."""
        stmt = select(AccountRecord).where(AccountRecord.id == account_id)
        result = await self._session.execute(stmt)
        record = result.scalar_one_or_none()

        if record is None:
            raise AccountNotFoundError(f"Account {account_id!r} not found in ledger")

        return Account(
            id=record.id,
            owner_id=record.owner_id,
            account_type=AccountType(record.account_type),
            currency=record.currency,
            name=record.name,
            is_active=record.is_active,
            created_at=record.created_at,
            metadata=record.metadata_ or {},
        )

    async def compute_balance(self, account_id: str) -> AccountBalance:
        """
        Derive account balance from the complete ledger entry set.
        This is the canonical, authoritative balance computation.
        """
        stmt = select(
            LedgerEntryRecord.currency,
            func.coalesce(
                func.sum(LedgerEntryRecord.amount).filter(
                    LedgerEntryRecord.direction == "debit"
                ),
                Decimal("0"),
            ).label("total_debits"),
            func.coalesce(
                func.sum(LedgerEntryRecord.amount).filter(
                    LedgerEntryRecord.direction == "credit"
                ),
                Decimal("0"),
            ).label("total_credits"),
        ).where(LedgerEntryRecord.account_id == account_id).group_by(LedgerEntryRecord.currency)

        result = await self._session.execute(stmt)
        rows = result.all()

        if not rows:
            # Account exists but has no entries — zero balance
            account = await self.fetch_account(account_id)
            return AccountBalance.compute(
                account_id=account_id,
                currency=account.currency,
                total_debits=Decimal("0"),
                total_credits=Decimal("0"),
            )

        # For simplicity, return primary currency balance
        row = rows[0]
        return AccountBalance.compute(
            account_id=account_id,
            currency=row.currency,
            total_debits=Decimal(str(row.total_debits)),
            total_credits=Decimal(str(row.total_credits)),
        )

    # ── Transaction Commitment ─────────────────────────────────────────────────

    async def commit_transaction(self, transaction: Transaction) -> TransactionResult:
        """
        Commit a validated transaction to the append-only ledger.

        This method is the sole authorised path for ledger mutation.
        It enforces all financial invariants before persistence.

        Raises:
            LedgerInvariantError: if the entry set is unbalanced
            AccountNotFoundError: if any referenced account does not exist
        """
        _log.transaction_initiated(
            transaction.id,
            {
                "type": transaction.transaction_type.value,
                "entry_count": len(transaction.entry_set.entries),
                "total_debits": str(transaction.entry_set.total_debits),
            },
        )

        # ── Invariant Check: Balance ──────────────────────────────────────────
        if not transaction.entry_set.is_balanced:
            raise LedgerInvariantError(
                f"Transaction {transaction.id} violates balance invariant: "
                f"Σ(debits)={transaction.entry_set.total_debits} ≠ "
                f"Σ(credits)={transaction.entry_set.total_credits}"
            )

        # ── Persist Transaction Record ────────────────────────────────────────
        tx_record = TransactionRecord(
            id=transaction.id,
            idempotency_key=transaction.idempotency_key,
            status=TransactionStatus.PENDING.value,
            transaction_type=transaction.transaction_type.value,
            reference=transaction.reference,
            initiated_by=transaction.initiated_by,
            metadata_=transaction.metadata,
        )
        self._session.add(tx_record)
        await self._session.flush()

        # ── Persist Ledger Entries (append-only) ──────────────────────────────
        entry_records = []
        for entry in transaction.entry_set.entries:
            record = LedgerEntryRecord(
                id=entry.id,
                transaction_id=transaction.id,
                account_id=entry.account_id,
                direction=entry.direction.value,
                amount=entry.amount,
                currency=entry.currency,
                sequence=entry.sequence,
                metadata_=entry.metadata,
            )
            self._session.add(record)
            entry_records.append(record)

        # ── Update Transaction Status ─────────────────────────────────────────
        now = datetime.now(timezone.utc)
        tx_record.status = TransactionStatus.COMMITTED.value
        tx_record.committed_at = now

        await self._session.flush()

        _log.transaction_committed(transaction.id, len(entry_records))

        return TransactionResult(
            transaction_id=transaction.id,
            status=TransactionStatus.COMMITTED,
            entry_count=len(entry_records),
            total_amount=transaction.entry_set.total_debits,
            currency=transaction.entry_set.entries[0].currency,
            committed_at=now,
            reference=transaction.reference,
            message="Transaction committed successfully to the ledger",
        )

    async def get_transaction_entries(self, transaction_id: str) -> list[LedgerEntry]:
        """Retrieve all ledger entries belonging to a transaction."""
        stmt = (
            select(LedgerEntryRecord)
            .where(LedgerEntryRecord.transaction_id == transaction_id)
            .order_by(LedgerEntryRecord.sequence)
        )
        result = await self._session.execute(stmt)
        records = result.scalars().all()

        return [
            LedgerEntry(
                id=r.id,
                transaction_id=r.transaction_id,
                account_id=r.account_id,
                direction=EntryDirection(r.direction),
                amount=Decimal(str(r.amount)),
                currency=r.currency,
                sequence=r.sequence,
                posted_at=r.posted_at,
                metadata=r.metadata_ or {},
            )
            for r in records
        ]

    async def get_account_entries(
        self,
        account_id: str,
        limit: int = 100,
        offset: int = 0,
    ) -> list[LedgerEntry]:
        """Retrieve ledger entries for a specific account, ordered by sequence."""
        stmt = (
            select(LedgerEntryRecord)
            .where(LedgerEntryRecord.account_id == account_id)
            .order_by(LedgerEntryRecord.posted_at.desc())
            .limit(limit)
            .offset(offset)
        )
        result = await self._session.execute(stmt)
        records = result.scalars().all()

        return [
            LedgerEntry(
                id=r.id,
                transaction_id=r.transaction_id,
                account_id=r.account_id,
                direction=EntryDirection(r.direction),
                amount=Decimal(str(r.amount)),
                currency=r.currency,
                sequence=r.sequence,
                posted_at=r.posted_at,
                metadata=r.metadata_ or {},
            )
            for r in records
        ]

    async def build_transfer_entries(
        self,
        transaction_id: str,
        source_account_id: str,
        destination_account_id: str,
        amount: Decimal,
        currency: str,
    ) -> EntrySet:
        """
        Construct the canonical double-entry pair for a transfer:
            DEBIT  source_account   (asset decreases)
            CREDIT destination_account (asset increases)
        """
        debit_entry = LedgerEntry(
            transaction_id=transaction_id,
            account_id=source_account_id,
            direction=EntryDirection.DEBIT,
            amount=amount,
            currency=currency,
            sequence=0,
        )
        credit_entry = LedgerEntry(
            transaction_id=transaction_id,
            account_id=destination_account_id,
            direction=EntryDirection.CREDIT,
            amount=amount,
            currency=currency,
            sequence=1,
        )
        return EntrySet(entries=(debit_entry, credit_entry))

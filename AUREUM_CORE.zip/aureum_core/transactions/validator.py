"""
AUREUM CORE — Transaction Validator
Pre-commit validation gate for all financial operations.
"""
from __future__ import annotations

from decimal import Decimal
from dataclasses import dataclass, field
from typing import Sequence

from aureum_core.ledger.accounts import Account, AccountType
from aureum_core.ledger.entries import EntryDirection, EntrySet
from aureum_core.ledger.transactions import TransferRequest
from aureum_core.utils.config import get_config
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("validator")
_config = get_config()


@dataclass(frozen=True)
class ValidationResult:
    is_valid: bool
    violations: tuple[str, ...] = field(default_factory=tuple)
    warnings: tuple[str, ...] = field(default_factory=tuple)

    @classmethod
    def passed(cls, warnings: Sequence[str] = ()) -> "ValidationResult":
        return cls(is_valid=True, violations=(), warnings=tuple(warnings))

    @classmethod
    def failed(cls, violations: Sequence[str], warnings: Sequence[str] = ()) -> "ValidationResult":
        return cls(is_valid=False, violations=tuple(violations), warnings=tuple(warnings))


class TransactionValidator:
    """
    Stateless validation engine applied to every transaction before ledger commit.
    Violations are fatal; warnings are informational.
    """

    def validate_transfer_request(
        self,
        request: TransferRequest,
        source_account: Account,
        destination_account: Account,
        source_balance: Decimal,
    ) -> ValidationResult:
        violations: list[str] = []
        warnings: list[str] = []

        # ── Account State Checks ──────────────────────────────────────────────
        if not source_account.is_active:
            violations.append(f"Source account {source_account.id} is inactive")
        if not destination_account.is_active:
            violations.append(f"Destination account {destination_account.id} is inactive")

        # ── Currency Consistency ──────────────────────────────────────────────
        if source_account.currency != request.currency:
            violations.append(
                f"Source account currency {source_account.currency} "
                f"does not match transfer currency {request.currency}"
            )
        if destination_account.currency != request.currency:
            violations.append(
                f"Destination account currency {destination_account.currency} "
                f"does not match transfer currency {request.currency}"
            )

        # ── Solvency Check (asset accounts only) ──────────────────────────────
        if source_account.account_type == AccountType.ASSET:
            available = source_balance
            if available < request.amount:
                violations.append(
                    f"Insufficient funds: available {available} {request.currency}, "
                    f"requested {request.amount} {request.currency}"
                )

        # ── Amount Limits ─────────────────────────────────────────────────────
        if request.currency == "GBP":
            if request.amount > _config.SINGLE_TRANSACTION_LIMIT_GBP:
                violations.append(
                    f"Transaction amount {request.amount} exceeds single-transaction limit "
                    f"{_config.SINGLE_TRANSACTION_LIMIT_GBP} GBP"
                )

        # ── Minimum Amount ────────────────────────────────────────────────────
        if request.amount < Decimal("0.01"):
            violations.append(f"Transaction amount {request.amount} below minimum 0.01")

        # ── Warnings ──────────────────────────────────────────────────────────
        if request.currency == "GBP" and request.amount >= _config.AML_THRESHOLD_GBP:
            warnings.append(
                f"Amount {request.amount} GBP meets or exceeds AML reporting threshold"
            )

        if violations:
            return ValidationResult.failed(violations, warnings)
        return ValidationResult.passed(warnings)

    def validate_entry_set(self, entry_set: EntrySet) -> ValidationResult:
        """Validate an already-constructed entry set for ledger readiness."""
        violations: list[str] = []

        if not entry_set.is_balanced:
            violations.append(
                f"Entry set imbalanced: Σ(debits)={entry_set.total_debits} "
                f"≠ Σ(credits)={entry_set.total_credits}"
            )

        if len(entry_set.entries) < 2:
            violations.append("Entry set must contain at least two entries")

        for entry in entry_set.entries:
            if entry.amount <= Decimal("0"):
                violations.append(f"Entry {entry.id} has non-positive amount: {entry.amount}")

        if violations:
            return ValidationResult.failed(violations)
        return ValidationResult.passed()

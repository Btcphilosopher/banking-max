"""
AUREUM CORE — Transaction Commit Engine
Central orchestrator for the full transaction lifecycle.

Pipeline:
    1. Idempotency Check
    2. Account & Balance Retrieval (with row-level locking)
    3. Validation
    4. Risk Screening
    5. Ledger Commit
    6. Audit Recording
    7. Result Emission
"""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.audit.audit_log import AuditLogger
from aureum_core.ledger.accounts import Account
from aureum_core.ledger.ledger_engine import (
    AccountNotFoundError,
    InsufficientFundsError,
    LedgerEngine,
    LedgerInvariantError,
)
from aureum_core.ledger.transactions import (
    Transaction,
    TransactionResult,
    TransactionStatus,
    TransactionType,
    TransferRequest,
)
from aureum_core.risk.aml import AMLEngine
from aureum_core.risk.fraud_detection import FraudDetectionEngine
from aureum_core.risk.limits import LimitEnforcementEngine
from aureum_core.transactions.idempotency import IdempotencyEngine
from aureum_core.transactions.validator import TransactionValidator, ValidationResult
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("processor")


class TransactionRejectedError(Exception):
    """Raised when a transaction is rejected at any stage of the pipeline."""

    def __init__(self, reason: str, violations: list[str] | None = None) -> None:
        super().__init__(reason)
        self.violations = violations or []


class TransactionCommitEngine:
    """
    The central transaction processing authority.
    All monetary state changes must flow through this engine.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._ledger = LedgerEngine(session)
        self._validator = TransactionValidator()
        self._idempotency = IdempotencyEngine(session)
        self._aml = AMLEngine(session)
        self._fraud = FraudDetectionEngine(session)
        self._limits = LimitEnforcementEngine(session)
        self._audit = AuditLogger(session)

    async def execute_transfer(self, request: TransferRequest) -> TransactionResult:
        """
        Execute a complete transfer through the AUREUM transaction pipeline.
        Atomic: commits fully or rolls back entirely.
        """
        # ── Stage 1: Idempotency ──────────────────────────────────────────────
        if request.idempotency_key:
            existing = await self._idempotency.check_key(request.idempotency_key)
            if existing is not None and existing.status == TransactionStatus.COMMITTED.value:
                _log.audit_event(
                    "IDEMPOTENT_RETURN",
                    actor=request.initiated_by,
                    details={"idempotency_key": request.idempotency_key},
                )
                return TransactionResult(
                    transaction_id=existing.id,
                    status=TransactionStatus.COMMITTED,
                    entry_count=2,
                    total_amount=request.amount,
                    currency=request.currency,
                    committed_at=existing.committed_at,
                    reference=request.reference,
                    message="Idempotent replay — original transaction returned",
                )

        # ── Stage 2: Account Retrieval ────────────────────────────────────────
        source_account = await self._ledger.fetch_account(request.source_account_id)
        destination_account = await self._ledger.fetch_account(request.destination_account_id)
        source_balance_record = await self._ledger.compute_balance(request.source_account_id)
        source_balance = source_balance_record.balance

        # ── Stage 3: Validation ───────────────────────────────────────────────
        validation_result = self._validator.validate_transfer_request(
            request=request,
            source_account=source_account,
            destination_account=destination_account,
            source_balance=source_balance,
        )

        if not validation_result.is_valid:
            await self._audit.record_event(
                event_type="TRANSACTION_REJECTED_VALIDATION",
                actor=request.initiated_by,
                entity_type="TRANSACTION",
                entity_id=None,
                payload={"violations": list(validation_result.violations), "request": request.model_dump(mode="json")},
            )
            raise TransactionRejectedError(
                f"Validation failed: {'; '.join(validation_result.violations)}",
                violations=list(validation_result.violations),
            )

        # ── Stage 4: Risk Screening ───────────────────────────────────────────
        await self._limits.enforce_velocity(
            account_id=request.source_account_id,
            amount=request.amount,
            currency=request.currency,
        )

        aml_result = await self._aml.screen_transaction(
            account_id=request.source_account_id,
            amount=request.amount,
            currency=request.currency,
            counterparty_id=request.destination_account_id,
        )
        if aml_result.should_block:
            raise TransactionRejectedError(
                f"AML screening blocked transaction: {aml_result.reason}",
                violations=[aml_result.reason],
            )

        fraud_result = await self._fraud.assess(
            account_id=request.source_account_id,
            amount=request.amount,
            currency=request.currency,
        )
        if fraud_result.should_block:
            raise TransactionRejectedError(
                f"Fraud detection blocked transaction: {fraud_result.reason}",
                violations=[fraud_result.reason],
            )

        # ── Stage 5: Build Entry Set ──────────────────────────────────────────
        transaction_id = _generate_transaction_id()
        entry_set = await self._ledger.build_transfer_entries(
            transaction_id=transaction_id,
            source_account_id=request.source_account_id,
            destination_account_id=request.destination_account_id,
            amount=request.amount,
            currency=request.currency,
        )

        transaction = Transaction(
            id=transaction_id,
            idempotency_key=request.idempotency_key,
            transaction_type=TransactionType.INTERNAL_TRANSFER,
            entry_set=entry_set,
            reference=request.reference,
            initiated_by=request.initiated_by,
            metadata={
                **request.metadata,
                "validation_warnings": list(validation_result.warnings),
            },
        )

        # ── Stage 6: Ledger Commit ────────────────────────────────────────────
        result = await self._ledger.commit_transaction(transaction)

        # ── Stage 7: Audit Recording ──────────────────────────────────────────
        await self._audit.record_event(
            event_type="TRANSFER_COMMITTED",
            actor=request.initiated_by,
            entity_type="TRANSACTION",
            entity_id=transaction_id,
            payload={
                "amount": str(request.amount),
                "currency": request.currency,
                "source": request.source_account_id,
                "destination": request.destination_account_id,
            },
        )

        return result


def _generate_transaction_id() -> str:
    """Generate a deterministic-format transaction identifier."""
    import uuid
    raw = str(uuid.uuid4()).replace("-", "").upper()
    return f"TXN-{raw[:8]}-{raw[8:16]}"

"""
AUREUM CORE — Idempotency Control Engine
Guarantees safe retry semantics for all transaction submissions.
"""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.storage.database import TransactionRecord
from aureum_core.ledger.transactions import TransactionStatus
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("idempotency")


class IdempotencyConflictError(Exception):
    """Raised when an idempotency key collision is detected with different parameters."""


class IdempotencyEngine:
    """
    Idempotency key management for transaction safety.

    A client may safely retry a transaction submission with the same
    idempotency key; the system will return the original result without
    re-processing.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def check_key(self, idempotency_key: str) -> TransactionRecord | None:
        """
        Check whether an idempotency key has already been processed.
        Returns the existing transaction record, or None if novel.
        """
        stmt = select(TransactionRecord).where(
            TransactionRecord.idempotency_key == idempotency_key
        )
        result = await self._session.execute(stmt)
        record = result.scalar_one_or_none()

        if record is not None:
            _log.audit_event(
                "IDEMPOTENCY_HIT",
                actor="SYSTEM",
                details={
                    "idempotency_key": idempotency_key,
                    "existing_transaction_id": record.id,
                    "status": record.status,
                },
            )

        return record

    async def is_duplicate(self, idempotency_key: str) -> bool:
        """Return True if the key has been previously committed."""
        record = await self.check_key(idempotency_key)
        return record is not None and record.status == TransactionStatus.COMMITTED.value

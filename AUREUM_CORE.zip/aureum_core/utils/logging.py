"""
AUREUM CORE — Structured Logging Infrastructure
Industrial-grade, deterministic log emission for financial audit trails.
"""
from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from typing import Any

import structlog


def configure_logging(level: str = "INFO") -> None:
    """Initialise structlog with JSON-formatted output for production ingestion."""
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, level.upper(), logging.INFO),
    )


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Return a named logger bound to the AUREUM namespace."""
    return structlog.get_logger(f"aureum.{name}")


class FinancialOperationLogger:
    """
    Dedicated logger for financial operations — ensures every
    material event is emitted with full transactional context.
    """

    def __init__(self, subsystem: str) -> None:
        self._log = get_logger(subsystem)
        self._subsystem = subsystem

    def transaction_initiated(self, transaction_id: str, metadata: dict[str, Any]) -> None:
        self._log.info(
            "TRANSACTION_INITIATED",
            transaction_id=transaction_id,
            subsystem=self._subsystem,
            **metadata,
        )

    def transaction_committed(self, transaction_id: str, entry_count: int) -> None:
        self._log.info(
            "TRANSACTION_COMMITTED",
            transaction_id=transaction_id,
            entry_count=entry_count,
            subsystem=self._subsystem,
        )

    def transaction_rejected(self, transaction_id: str, reason: str) -> None:
        self._log.warning(
            "TRANSACTION_REJECTED",
            transaction_id=transaction_id,
            reason=reason,
            subsystem=self._subsystem,
        )

    def risk_event(self, event_type: str, account_id: str, details: dict[str, Any]) -> None:
        self._log.warning(
            "RISK_EVENT",
            event_type=event_type,
            account_id=account_id,
            subsystem=self._subsystem,
            **details,
        )

    def audit_event(self, action: str, actor: str, details: dict[str, Any]) -> None:
        self._log.info(
            "AUDIT_EVENT",
            action=action,
            actor=actor,
            subsystem=self._subsystem,
            **details,
        )

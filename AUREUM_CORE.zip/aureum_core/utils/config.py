"""
AUREUM CORE — Configuration Registry
Sovereign-grade parameter management for the banking kernel.
"""
from __future__ import annotations

import os
from functools import lru_cache
from decimal import Decimal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings


class AureumConfig(BaseSettings):
    """Central configuration manifest for AUREUM CORE."""

    # ── Identity ──────────────────────────────────────────────────────────────
    INSTITUTION_NAME: str = "AUREUM FINANCIAL INSTITUTION"
    INSTITUTION_BIC: str = "AUREUMXXXX"
    BASE_CURRENCY: str = "GBP"

    # ── Database ──────────────────────────────────────────────────────────────
    DATABASE_URL: str = Field(
        default="postgresql+asyncpg://aureum:aureum@localhost:5432/aureum_core",
        description="Primary ACID-compliant datastore URI",
    )
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 10

    # ── Authentication ─────────────────────────────────────────────────────────
    JWT_SECRET_KEY: str = Field(
        default="CHANGE_IN_PRODUCTION_aureum_sovereign_key_2024",
        description="HMAC-SHA256 signing key for JWT issuance",
    )
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRY_MINUTES: int = 60

    # ── Transaction Limits ─────────────────────────────────────────────────────
    SINGLE_TRANSACTION_LIMIT_GBP: Decimal = Decimal("1_000_000.00")
    DAILY_VELOCITY_LIMIT_GBP: Decimal = Decimal("5_000_000.00")
    AML_THRESHOLD_GBP: Decimal = Decimal("10_000.00")

    # ── Settlement ─────────────────────────────────────────────────────────────
    FASTER_PAYMENTS_MAX_GBP: Decimal = Decimal("1_000_000.00")
    SWIFT_SETTLEMENT_DAYS: int = 2
    SEPA_SETTLEMENT_DAYS: int = 1

    # ── Risk ───────────────────────────────────────────────────────────────────
    FRAUD_VELOCITY_WINDOW_SECONDS: int = 300
    FRAUD_VELOCITY_MAX_TRANSACTIONS: int = 10
    FRAUD_RAPID_SUCCESSION_THRESHOLD: int = 5

    # ── API ────────────────────────────────────────────────────────────────────
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    API_DEBUG: bool = False

    class Config:
        env_file = ".env"
        env_prefix = "AUREUM_"


@lru_cache(maxsize=1)
def get_config() -> AureumConfig:
    """Return singleton configuration instance."""
    return AureumConfig()

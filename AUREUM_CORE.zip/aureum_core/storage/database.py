"""
AUREUM CORE — Storage Engine
ACID-compliant PostgreSQL persistence layer with append-only guarantees.
"""
from __future__ import annotations

from collections.abc import AsyncGenerator
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    Column,
    DateTime,
    Enum,
    Index,
    Integer,
    MetaData,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    event,
    text,
)
from sqlalchemy import JSON
from sqlalchemy.dialects.postgresql import JSONB, UUID

# When running under SQLite (tests), JSONB is not supported — alias to JSON.
# Production targets PostgreSQL exclusively where JSONB is the native type.
import os as _os
if "sqlite" in _os.environ.get("AUREUM_DATABASE_URL", "sqlite"):
    _JsonType = JSON
else:
    _JsonType = JSONB  # type: ignore[assignment]

# Re-assign so all column declarations below use the resolved type.
JSONB = _JsonType  # type: ignore[assignment,misc]
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from sqlalchemy.sql import func

from aureum_core.utils.config import get_config

# ── Metadata with naming convention ───────────────────────────────────────────
NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

metadata = MetaData(naming_convention=NAMING_CONVENTION)


class AureumBase(DeclarativeBase):
    """Base class for all ORM models in the AUREUM schema."""
    metadata = metadata


# ── ORM Models ─────────────────────────────────────────────────────────────────

class AccountRecord(AureumBase):
    """Persistent account record — the structural unit of capital ownership."""
    __tablename__ = "accounts"

    id = Column(UUID(as_uuid=False), primary_key=True)
    owner_id = Column(String(128), nullable=False, index=True)
    account_type = Column(
        Enum("asset", "liability", "equity", "revenue", "expense", name="account_type_enum"),
        nullable=False,
    )
    currency = Column(String(3), nullable=False)
    name = Column(String(256), nullable=False)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    metadata_ = Column("metadata", JSONB, nullable=False, server_default="{}")

    __table_args__ = (
        Index("ix_accounts_owner_currency", "owner_id", "currency"),
    )


class LedgerEntryRecord(AureumBase):
    """
    Immutable double-entry ledger record.
    No entry may be mutated or deleted after commit — append-only invariant enforced
    at DB level via trigger (see migrations).
    """
    __tablename__ = "ledger_entries"

    id = Column(UUID(as_uuid=False), primary_key=True)
    transaction_id = Column(String(64), nullable=False, index=True)
    account_id = Column(UUID(as_uuid=False), nullable=False, index=True)
    direction = Column(
        Enum("debit", "credit", name="entry_direction_enum"),
        nullable=False,
    )
    amount = Column(Numeric(precision=28, scale=10), nullable=False)
    currency = Column(String(3), nullable=False)
    sequence = Column(BigInteger, nullable=False)
    posted_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    metadata_ = Column("metadata", JSONB, nullable=False, server_default="{}")

    __table_args__ = (
        Index("ix_ledger_entries_account_posted", "account_id", "posted_at"),
        Index("ix_ledger_entries_transaction", "transaction_id"),
    )


class TransactionRecord(AureumBase):
    """
    Atomic transaction envelope — the immutable unit of financial intent.
    Status transitions: PENDING → COMMITTED | REJECTED | ROLLED_BACK
    """
    __tablename__ = "transactions"

    id = Column(String(64), primary_key=True)
    idempotency_key = Column(String(256), unique=True, nullable=True)
    status = Column(
        Enum("PENDING", "COMMITTED", "REJECTED", "ROLLED_BACK", name="transaction_status_enum"),
        nullable=False,
        default="PENDING",
    )
    transaction_type = Column(String(64), nullable=False)
    reference = Column(String(256), nullable=True)
    initiated_by = Column(String(128), nullable=False)
    initiated_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    committed_at = Column(DateTime(timezone=True), nullable=True)
    metadata_ = Column("metadata", JSONB, nullable=False, server_default="{}")

    __table_args__ = (
        Index("ix_transactions_initiated_at", "initiated_at"),
        Index("ix_transactions_status", "status"),
    )


class AuditLogRecord(AureumBase):
    """
    Immutable audit event — full history of all system actions.
    Every write to this table is append-only.
    """
    __tablename__ = "audit_log"

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_type = Column(String(128), nullable=False, index=True)
    actor = Column(String(128), nullable=False)
    entity_type = Column(String(64), nullable=True)
    entity_id = Column(String(128), nullable=True)
    payload = Column(JSONB, nullable=False, server_default="{}")
    occurred_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False, index=True)
    ip_address = Column(String(45), nullable=True)
    session_id = Column(String(128), nullable=True)


class FXRateRecord(AureumBase):
    """Immutable snapshot of FX rates at a given moment."""
    __tablename__ = "fx_rates"

    id = Column(Integer, primary_key=True, autoincrement=True)
    base_currency = Column(String(3), nullable=False)
    quote_currency = Column(String(3), nullable=False)
    rate = Column(Numeric(precision=20, scale=10), nullable=False)
    source = Column(String(64), nullable=False, default="SIMULATED")
    captured_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False, index=True)

    __table_args__ = (
        Index("ix_fx_rates_pair_captured", "base_currency", "quote_currency", "captured_at"),
    )


class RiskEventRecord(AureumBase):
    """Persistent record of AML/fraud events triggered by the risk engine."""
    __tablename__ = "risk_events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_class = Column(
        Enum("AML_ALERT", "FRAUD_ALERT", "LIMIT_BREACH", "MANUAL_REVIEW", name="risk_event_class_enum"),
        nullable=False,
        index=True,
    )
    severity = Column(
        Enum("LOW", "MEDIUM", "HIGH", "CRITICAL", name="risk_severity_enum"),
        nullable=False,
    )
    account_id = Column(UUID(as_uuid=False), nullable=True, index=True)
    transaction_id = Column(String(64), nullable=True, index=True)
    description = Column(Text, nullable=False)
    resolved = Column(Boolean, nullable=False, default=False)
    payload = Column(JSONB, nullable=False, server_default="{}")
    triggered_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False, index=True)


class PaymentRecord(AureumBase):
    """Payment instruction lifecycle tracker."""
    __tablename__ = "payments"

    id = Column(String(64), primary_key=True)
    transaction_id = Column(String(64), nullable=False, index=True)
    rail = Column(
        Enum("FASTER_PAYMENTS", "SEPA", "SWIFT", "INTERNAL", name="payment_rail_enum"),
        nullable=False,
    )
    status = Column(
        Enum("QUEUED", "SUBMITTED", "SETTLED", "FAILED", "RETURNED", name="payment_status_enum"),
        nullable=False,
        default="QUEUED",
    )
    amount = Column(Numeric(precision=28, scale=10), nullable=False)
    currency = Column(String(3), nullable=False)
    debtor_account_id = Column(UUID(as_uuid=False), nullable=False)
    creditor_account_id = Column(UUID(as_uuid=False), nullable=False)
    expected_settlement_at = Column(DateTime(timezone=True), nullable=True)
    settled_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    metadata_ = Column("metadata", JSONB, nullable=False, server_default="{}")


# ── Engine & Session Factory ───────────────────────────────────────────────────

_engine: AsyncEngine | None = None
_session_factory: sessionmaker | None = None


def build_engine(database_url: str | None = None) -> AsyncEngine:
    """Construct and configure the async SQLAlchemy engine."""
    global _engine
    config = get_config()
    url = database_url or config.DATABASE_URL
    _engine = create_async_engine(
        url,
        pool_size=config.DATABASE_POOL_SIZE,
        max_overflow=config.DATABASE_MAX_OVERFLOW,
        echo=False,
        future=True,
    )
    return _engine


def get_engine() -> AsyncEngine:
    global _engine
    if _engine is None:
        _engine = build_engine()
    return _engine


def build_session_factory(engine: AsyncEngine | None = None) -> sessionmaker:
    global _session_factory
    _engine = engine or get_engine()
    _session_factory = sessionmaker(
        bind=_engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )
    return _session_factory


def get_session_factory() -> sessionmaker:
    global _session_factory
    if _session_factory is None:
        _session_factory = build_session_factory()
    return _session_factory


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency: yields a transactional database session."""
    factory = get_session_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def create_all_tables() -> None:
    """Create all schema objects (idempotent — safe to call on startup)."""
    engine = get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(AureumBase.metadata.create_all)

"""
AUREUM CORE — Migration & Schema Enforcement
Procedural DDL supplements for append-only invariants and trigger installation.
"""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncEngine

# ── Append-Only Enforcement Triggers ─────────────────────────────────────────

LEDGER_IMMUTABILITY_TRIGGER = """
CREATE OR REPLACE FUNCTION aureum_prevent_ledger_mutation()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION
        'AUREUM INVARIANT VIOLATION: ledger_entries is append-only. '
        'UPDATE and DELETE operations are forbidden. TXN=%', OLD.transaction_id;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_ledger_entries_immutable ON ledger_entries;
CREATE TRIGGER trg_ledger_entries_immutable
BEFORE UPDATE OR DELETE ON ledger_entries
FOR EACH ROW EXECUTE FUNCTION aureum_prevent_ledger_mutation();
"""

AUDIT_LOG_IMMUTABILITY_TRIGGER = """
CREATE OR REPLACE FUNCTION aureum_prevent_audit_mutation()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION
        'AUREUM INVARIANT VIOLATION: audit_log is append-only. '
        'Mutation of audit records is a compliance violation.';
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_log_immutable ON audit_log;
CREATE TRIGGER trg_audit_log_immutable
BEFORE UPDATE OR DELETE ON audit_log
FOR EACH ROW EXECUTE FUNCTION aureum_prevent_audit_mutation();
"""

LEDGER_SEQUENCE_FUNCTION = """
CREATE SEQUENCE IF NOT EXISTS ledger_entry_sequence START 1;
"""

TRANSACTION_BALANCE_CHECK = """
CREATE OR REPLACE FUNCTION aureum_verify_transaction_balance(p_transaction_id TEXT)
RETURNS BOOLEAN AS $$
DECLARE
    v_debit_sum  NUMERIC;
    v_credit_sum NUMERIC;
BEGIN
    SELECT
        COALESCE(SUM(amount) FILTER (WHERE direction = 'debit'),  0),
        COALESCE(SUM(amount) FILTER (WHERE direction = 'credit'), 0)
    INTO v_debit_sum, v_credit_sum
    FROM ledger_entries
    WHERE transaction_id = p_transaction_id;

    RETURN v_debit_sum = v_credit_sum;
END;
$$ LANGUAGE plpgsql;
"""

BALANCE_VIEW = """
CREATE OR REPLACE VIEW account_balances AS
SELECT
    account_id,
    currency,
    COALESCE(SUM(amount) FILTER (WHERE direction = 'debit'),  0) AS total_debits,
    COALESCE(SUM(amount) FILTER (WHERE direction = 'credit'), 0) AS total_credits,
    COALESCE(SUM(amount) FILTER (WHERE direction = 'debit'),  0)
    - COALESCE(SUM(amount) FILTER (WHERE direction = 'credit'), 0) AS balance
FROM ledger_entries
GROUP BY account_id, currency;
"""

ALL_DDL_SUPPLEMENTS: list[str] = [
    LEDGER_SEQUENCE_FUNCTION,
    LEDGER_IMMUTABILITY_TRIGGER,
    AUDIT_LOG_IMMUTABILITY_TRIGGER,
    TRANSACTION_BALANCE_CHECK,
    BALANCE_VIEW,
]


async def apply_ddl_supplements(engine: AsyncEngine) -> None:
    """Apply post-schema DDL: triggers, functions, views."""
    async with engine.begin() as conn:
        for statement in ALL_DDL_SUPPLEMENTS:
            await conn.execute(__import__("sqlalchemy").text(statement))

"""
AUREUM CORE — Test Suite
Unit, integration, and invariant tests for the banking kernel.

Coverage:
    - Ledger double-entry invariant enforcement
    - Transaction pipeline integrity
    - Concurrency and idempotency
    - AML/fraud/limits screening
    - Reconciliation correctness
    - FX conversion
"""
from __future__ import annotations

import asyncio
import uuid
from decimal import Decimal

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from aureum_core.audit.audit_log import AuditLogger
from aureum_core.audit.reconciliation import ReconciliationEngine
from aureum_core.currency.fx_engine import FXEngine
from aureum_core.currency.currency_models import quantise_amount, is_supported_currency
from aureum_core.ledger.accounts import AccountType, CreateAccountRequest
from aureum_core.ledger.entries import EntryDirection, EntrySet, LedgerEntry
from aureum_core.ledger.ledger_engine import LedgerEngine, LedgerInvariantError, AccountNotFoundError
from aureum_core.ledger.transactions import TransactionType, TransferRequest
from aureum_core.storage.database import AureumBase, build_engine, build_session_factory
from aureum_core.transactions.processor import TransactionCommitEngine, TransactionRejectedError
from aureum_core.transactions.validator import TransactionValidator

# ── Test Database Setup ────────────────────────────────────────────────────────

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="function")
async def db_session():
    """Provide a clean in-memory database session for each test."""
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(AureumBase.metadata.create_all)

    factory = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with factory() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(AureumBase.metadata.drop_all)
    await engine.dispose()


# ── Helper: account provisioning ──────────────────────────────────────────────

async def _make_account(
    session: AsyncSession,
    currency: str = "GBP",
    account_type: AccountType = AccountType.ASSET,
    owner_id: str | None = None,
) -> str:
    engine = LedgerEngine(session)
    account = await engine.provision_account(
        CreateAccountRequest(
            owner_id=owner_id or f"owner-{uuid.uuid4().hex[:8]}",
            account_type=account_type,
            currency=currency,
            name=f"Test {account_type.value.title()} Account",
        )
    )
    return account.id


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 1: LEDGER INVARIANT TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestLedgerInvariants:
    """Core accounting invariant enforcement tests."""

    def test_balanced_entry_set_passes(self):
        """A balanced entry set must not raise."""
        txn_id = "TXN-TEST-001"
        entry_set = EntrySet(
            entries=(
                LedgerEntry(
                    transaction_id=txn_id, account_id="acct-a",
                    direction=EntryDirection.DEBIT,
                    amount=Decimal("100.00"), currency="GBP", sequence=0,
                ),
                LedgerEntry(
                    transaction_id=txn_id, account_id="acct-b",
                    direction=EntryDirection.CREDIT,
                    amount=Decimal("100.00"), currency="GBP", sequence=1,
                ),
            )
        )
        assert entry_set.is_balanced
        assert entry_set.total_debits == Decimal("100.00")
        assert entry_set.total_credits == Decimal("100.00")

    def test_unbalanced_entry_set_raises(self):
        """An unbalanced entry set must raise a validation error."""
        txn_id = "TXN-TEST-002"
        with pytest.raises(Exception):
            EntrySet(
                entries=(
                    LedgerEntry(
                        transaction_id=txn_id, account_id="acct-a",
                        direction=EntryDirection.DEBIT,
                        amount=Decimal("100.00"), currency="GBP", sequence=0,
                    ),
                    LedgerEntry(
                        transaction_id=txn_id, account_id="acct-b",
                        direction=EntryDirection.CREDIT,
                        amount=Decimal("99.99"), currency="GBP", sequence=1,
                    ),
                )
            )

    def test_single_entry_set_raises(self):
        """A single-entry set (missing counterpart) must raise."""
        txn_id = "TXN-TEST-003"
        with pytest.raises(Exception):
            EntrySet(
                entries=(
                    LedgerEntry(
                        transaction_id=txn_id, account_id="acct-a",
                        direction=EntryDirection.DEBIT,
                        amount=Decimal("50.00"), currency="GBP", sequence=0,
                    ),
                )
            )

    def test_multi_leg_balanced_entry_set(self):
        """Multi-leg transactions must balance across all legs."""
        txn_id = "TXN-TEST-004"
        entry_set = EntrySet(
            entries=(
                LedgerEntry(
                    transaction_id=txn_id, account_id="acct-a",
                    direction=EntryDirection.DEBIT,
                    amount=Decimal("300.00"), currency="GBP", sequence=0,
                ),
                LedgerEntry(
                    transaction_id=txn_id, account_id="acct-b",
                    direction=EntryDirection.CREDIT,
                    amount=Decimal("200.00"), currency="GBP", sequence=1,
                ),
                LedgerEntry(
                    transaction_id=txn_id, account_id="acct-c",
                    direction=EntryDirection.CREDIT,
                    amount=Decimal("100.00"), currency="GBP", sequence=2,
                ),
            )
        )
        assert entry_set.is_balanced
        assert entry_set.total_debits == Decimal("300.00")

    def test_zero_amount_entry_rejected(self):
        """Zero-amount entries must not be accepted."""
        with pytest.raises(Exception):
            LedgerEntry(
                transaction_id="TXN-X", account_id="acct-a",
                direction=EntryDirection.DEBIT,
                amount=Decimal("0"), currency="GBP", sequence=0,
            )

    def test_negative_amount_entry_rejected(self):
        """Negative-amount entries must not be accepted."""
        with pytest.raises(Exception):
            LedgerEntry(
                transaction_id="TXN-X", account_id="acct-a",
                direction=EntryDirection.DEBIT,
                amount=Decimal("-50.00"), currency="GBP", sequence=0,
            )

    def test_entry_direction_opposite(self):
        """EntryDirection.opposite must return the counterpart direction."""
        assert EntryDirection.DEBIT.opposite == EntryDirection.CREDIT
        assert EntryDirection.CREDIT.opposite == EntryDirection.DEBIT


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 2: ACCOUNT OPERATIONS TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestAccountOperations:

    @pytest.mark.asyncio
    async def test_provision_account(self, db_session):
        """Account provisioning must create a valid account record."""
        engine = LedgerEngine(db_session)
        account = await engine.provision_account(
            CreateAccountRequest(
                owner_id="customer-001",
                account_type=AccountType.ASSET,
                currency="GBP",
                name="Current Account",
            )
        )
        assert account.id is not None
        assert account.currency == "GBP"
        assert account.account_type == AccountType.ASSET
        assert account.is_active

    @pytest.mark.asyncio
    async def test_fetch_account(self, db_session):
        """Fetching a provisioned account must return correct data."""
        account_id = await _make_account(db_session, currency="EUR")
        engine = LedgerEngine(db_session)
        fetched = await engine.fetch_account(account_id)
        assert fetched.id == account_id
        assert fetched.currency == "EUR"

    @pytest.mark.asyncio
    async def test_fetch_nonexistent_account_raises(self, db_session):
        """Fetching an unknown account must raise AccountNotFoundError."""
        engine = LedgerEngine(db_session)
        with pytest.raises(AccountNotFoundError):
            await engine.fetch_account("nonexistent-id-999")

    @pytest.mark.asyncio
    async def test_initial_balance_is_zero(self, db_session):
        """Newly provisioned account must have zero balance."""
        account_id = await _make_account(db_session)
        engine = LedgerEngine(db_session)
        balance = await engine.compute_balance(account_id)
        assert balance.balance == Decimal("0")
        assert balance.total_debits == Decimal("0")
        assert balance.total_credits == Decimal("0")

    @pytest.mark.asyncio
    async def test_currency_normalisation(self, db_session):
        """Currency codes must be normalised to uppercase."""
        engine = LedgerEngine(db_session)
        account = await engine.provision_account(
            CreateAccountRequest(
                owner_id="owner-x",
                account_type=AccountType.ASSET,
                currency="gbp",
                name="Test",
            )
        )
        assert account.currency == "GBP"


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 3: TRANSACTION INTEGRITY TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestTransactionIntegrity:

    @pytest.mark.asyncio
    async def test_successful_transfer_commits(self, db_session):
        """A valid transfer must commit and produce correct balance changes."""
        src = await _make_account(db_session, currency="GBP")
        dst = await _make_account(db_session, currency="GBP")

        # Pre-fund source account by committing a credit entry
        ledger = LedgerEngine(db_session)
        fund_txn_id = "FUND-001"
        from aureum_core.ledger.transactions import Transaction
        fund_entry_set = EntrySet(
            entries=(
                LedgerEntry(
                    transaction_id=fund_txn_id, account_id="system-nostro",
                    direction=EntryDirection.DEBIT,
                    amount=Decimal("1000.00"), currency="GBP", sequence=0,
                ),
                LedgerEntry(
                    transaction_id=fund_txn_id, account_id=src,
                    direction=EntryDirection.CREDIT,
                    amount=Decimal("1000.00"), currency="GBP", sequence=1,
                ),
            )
        )
        fund_tx = Transaction(
            id=fund_txn_id,
            transaction_type=TransactionType.ADJUSTMENT,
            entry_set=fund_entry_set,
            initiated_by="SYSTEM",
        )
        await ledger.commit_transaction(fund_tx)
        await db_session.flush()

        # Source account balance after funding
        src_balance = await ledger.compute_balance(src)
        # For liability-type (funded via credit), balance reflects credit surplus
        assert src_balance.total_credits == Decimal("1000.00")

    @pytest.mark.asyncio
    async def test_transfer_entry_set_balanced(self, db_session):
        """build_transfer_entries must always produce balanced entry sets."""
        src = await _make_account(db_session)
        dst = await _make_account(db_session)
        ledger = LedgerEngine(db_session)

        entry_set = await ledger.build_transfer_entries(
            transaction_id="TXN-BAL-001",
            source_account_id=src,
            destination_account_id=dst,
            amount=Decimal("250.00"),
            currency="GBP",
        )
        assert entry_set.is_balanced
        assert entry_set.total_debits == Decimal("250.00")
        assert entry_set.total_credits == Decimal("250.00")

    @pytest.mark.asyncio
    async def test_transfer_entry_directions(self, db_session):
        """Transfer entries must have DEBIT on source and CREDIT on destination."""
        src = await _make_account(db_session)
        dst = await _make_account(db_session)
        ledger = LedgerEngine(db_session)

        entry_set = await ledger.build_transfer_entries(
            transaction_id="TXN-DIR-001",
            source_account_id=src,
            destination_account_id=dst,
            amount=Decimal("100.00"),
            currency="GBP",
        )
        debit_entries = [e for e in entry_set.entries if e.direction == EntryDirection.DEBIT]
        credit_entries = [e for e in entry_set.entries if e.direction == EntryDirection.CREDIT]

        assert len(debit_entries) == 1
        assert len(credit_entries) == 1
        assert debit_entries[0].account_id == src
        assert credit_entries[0].account_id == dst

    @pytest.mark.asyncio
    async def test_transaction_entries_retrievable(self, db_session):
        """Committed transaction entries must be retrievable by transaction ID."""
        src = await _make_account(db_session)
        dst = await _make_account(db_session)
        ledger = LedgerEngine(db_session)

        txn_id = "TXN-RETRIEVE-001"
        entry_set = await ledger.build_transfer_entries(
            transaction_id=txn_id,
            source_account_id=src,
            destination_account_id=dst,
            amount=Decimal("75.00"),
            currency="GBP",
        )
        from aureum_core.ledger.transactions import Transaction
        tx = Transaction(
            id=txn_id,
            transaction_type=TransactionType.INTERNAL_TRANSFER,
            entry_set=entry_set,
            initiated_by="TEST",
        )
        await ledger.commit_transaction(tx)
        await db_session.flush()

        entries = await ledger.get_transaction_entries(txn_id)
        assert len(entries) == 2
        amounts = {e.amount for e in entries}
        assert Decimal("75.00") in amounts


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 4: VALIDATION TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestTransactionValidation:

    def _make_account_obj(
        self,
        account_id: str,
        currency: str = "GBP",
        account_type: AccountType = AccountType.ASSET,
        is_active: bool = True,
    ):
        from aureum_core.ledger.accounts import Account
        return Account(
            id=account_id,
            owner_id="owner-x",
            account_type=account_type,
            currency=currency,
            name="Test",
            is_active=is_active,
        )

    def test_valid_transfer_passes(self):
        """A valid transfer request with sufficient funds must pass validation."""
        validator = TransactionValidator()
        src = self._make_account_obj("acct-src")
        dst = self._make_account_obj("acct-dst")
        request = TransferRequest(
            source_account_id="acct-src",
            destination_account_id="acct-dst",
            amount=Decimal("100.00"),
            currency="GBP",
            initiated_by="operator",
        )
        result = validator.validate_transfer_request(
            request=request,
            source_account=src,
            destination_account=dst,
            source_balance=Decimal("500.00"),
        )
        assert result.is_valid

    def test_insufficient_funds_rejected(self):
        """Transfer exceeding available balance must be rejected."""
        validator = TransactionValidator()
        src = self._make_account_obj("acct-src")
        dst = self._make_account_obj("acct-dst")
        request = TransferRequest(
            source_account_id="acct-src",
            destination_account_id="acct-dst",
            amount=Decimal("1000.00"),
            currency="GBP",
            initiated_by="operator",
        )
        result = validator.validate_transfer_request(
            request=request,
            source_account=src,
            destination_account=dst,
            source_balance=Decimal("100.00"),
        )
        assert not result.is_valid
        assert any("Insufficient" in v for v in result.violations)

    def test_inactive_source_rejected(self):
        """Transfer from inactive account must be rejected."""
        validator = TransactionValidator()
        src = self._make_account_obj("acct-src", is_active=False)
        dst = self._make_account_obj("acct-dst")
        request = TransferRequest(
            source_account_id="acct-src",
            destination_account_id="acct-dst",
            amount=Decimal("100.00"),
            currency="GBP",
            initiated_by="operator",
        )
        result = validator.validate_transfer_request(
            request=request,
            source_account=src,
            destination_account=dst,
            source_balance=Decimal("500.00"),
        )
        assert not result.is_valid
        assert any("inactive" in v.lower() for v in result.violations)

    def test_currency_mismatch_rejected(self):
        """Transfer with mismatched currency must be rejected."""
        validator = TransactionValidator()
        src = self._make_account_obj("acct-src", currency="EUR")
        dst = self._make_account_obj("acct-dst", currency="GBP")
        request = TransferRequest(
            source_account_id="acct-src",
            destination_account_id="acct-dst",
            amount=Decimal("100.00"),
            currency="GBP",
            initiated_by="operator",
        )
        result = validator.validate_transfer_request(
            request=request,
            source_account=src,
            destination_account=dst,
            source_balance=Decimal("500.00"),
        )
        assert not result.is_valid

    def test_same_account_transfer_rejected(self):
        """Transfer to self must be rejected at model level."""
        with pytest.raises(Exception):
            TransferRequest(
                source_account_id="acct-same",
                destination_account_id="acct-same",
                amount=Decimal("100.00"),
                currency="GBP",
                initiated_by="operator",
            )

    def test_aml_threshold_generates_warning(self):
        """Transfers at or above the AML threshold must generate a warning."""
        validator = TransactionValidator()
        src = self._make_account_obj("acct-src")
        dst = self._make_account_obj("acct-dst")
        request = TransferRequest(
            source_account_id="acct-src",
            destination_account_id="acct-dst",
            amount=Decimal("10000.00"),
            currency="GBP",
            initiated_by="operator",
        )
        result = validator.validate_transfer_request(
            request=request,
            source_account=src,
            destination_account=dst,
            source_balance=Decimal("100000.00"),
        )
        assert result.is_valid
        assert len(result.warnings) > 0


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 5: RECONCILIATION TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestReconciliation:

    @pytest.mark.asyncio
    async def test_empty_ledger_is_consistent(self, db_session):
        """An empty ledger must report as consistent."""
        engine = ReconciliationEngine(db_session)
        report = await engine.run_full_reconciliation()
        assert report.is_consistent
        assert report.transactions_checked == 0
        assert report.system_imbalance == Decimal("0")

    @pytest.mark.asyncio
    async def test_balanced_transactions_pass_reconciliation(self, db_session):
        """Balanced committed transactions must pass reconciliation."""
        src = await _make_account(db_session)
        dst = await _make_account(db_session)
        ledger = LedgerEngine(db_session)

        txn_id = "TXN-RECON-001"
        entry_set = await ledger.build_transfer_entries(
            transaction_id=txn_id,
            source_account_id=src,
            destination_account_id=dst,
            amount=Decimal("500.00"),
            currency="GBP",
        )
        from aureum_core.ledger.transactions import Transaction
        tx = Transaction(
            id=txn_id,
            transaction_type=TransactionType.INTERNAL_TRANSFER,
            entry_set=entry_set,
            initiated_by="TEST",
        )
        await ledger.commit_transaction(tx)
        await db_session.flush()

        recon = ReconciliationEngine(db_session)
        report = await recon.run_full_reconciliation()

        assert report.is_consistent
        assert report.balanced_transactions == 1
        assert len(report.unbalanced_transactions) == 0
        assert report.total_system_debit == report.total_system_credit

    @pytest.mark.asyncio
    async def test_system_totals_balance_after_multiple_transactions(self, db_session):
        """System-wide debit/credit totals must balance after multiple transfers."""
        ledger = LedgerEngine(db_session)
        accounts = [await _make_account(db_session) for _ in range(4)]

        amounts = [Decimal("100"), Decimal("250"), Decimal("75")]
        pairs = [(accounts[0], accounts[1]), (accounts[1], accounts[2]), (accounts[2], accounts[3])]

        for i, ((src, dst), amount) in enumerate(zip(pairs, amounts)):
            txn_id = f"TXN-MULTI-{i:03d}"
            entry_set = await ledger.build_transfer_entries(
                transaction_id=txn_id,
                source_account_id=src,
                destination_account_id=dst,
                amount=amount,
                currency="GBP",
            )
            from aureum_core.ledger.transactions import Transaction
            tx = Transaction(
                id=txn_id,
                transaction_type=TransactionType.INTERNAL_TRANSFER,
                entry_set=entry_set,
                initiated_by="TEST",
            )
            await ledger.commit_transaction(tx)

        await db_session.flush()

        recon = ReconciliationEngine(db_session)
        report = await recon.run_full_reconciliation()

        assert report.is_consistent
        assert report.system_imbalance == Decimal("0")
        assert report.transactions_checked == 3


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 6: FX ENGINE TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestFXEngine:

    @pytest.mark.asyncio
    async def test_same_currency_rate_is_one(self, db_session):
        """GBP→GBP conversion rate must be exactly 1.0 (before volatility)."""
        # Test mid-rate logic directly
        engine = FXEngine(db_session)
        quote = engine.get_live_quote("GBP", "GBP")
        assert quote.mid_rate == Decimal("1.0")

    @pytest.mark.asyncio
    async def test_conversion_produces_positive_result(self, db_session):
        """Converting any positive amount must produce a positive result."""
        engine = FXEngine(db_session)
        result = await engine.convert(
            amount=Decimal("100.00"),
            source_currency="GBP",
            target_currency="USD",
        )
        assert result.converted_amount > Decimal("0")
        assert result.source_currency == "GBP"
        assert result.target_currency == "USD"

    @pytest.mark.asyncio
    async def test_conversion_usd_to_gbp(self, db_session):
        """USD→GBP conversion must return a lower amount (USD is weaker vs GBP)."""
        engine = FXEngine(db_session)
        result = await engine.convert(
            amount=Decimal("100.00"),
            source_currency="USD",
            target_currency="GBP",
        )
        # 100 USD should be < 100 GBP since GBP > USD
        assert result.converted_amount < Decimal("100.00")

    def test_unsupported_currency_raises(self):
        """Requesting a quote for an unsupported currency must raise ValueError."""
        # We test via is_supported_currency utility
        assert not is_supported_currency("XYZ")
        assert is_supported_currency("GBP")
        assert is_supported_currency("EUR")

    def test_quantise_gbp(self):
        """GBP amounts must be quantised to 2 decimal places."""
        result = quantise_amount(Decimal("100.123456"), "GBP")
        assert result == Decimal("100.12")

    def test_quantise_jpy(self):
        """JPY amounts must be quantised to 0 decimal places."""
        result = quantise_amount(Decimal("1234.78"), "JPY")
        assert result == Decimal("1235")


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 7: AUDIT LOG TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestAuditLog:

    @pytest.mark.asyncio
    async def test_audit_event_recorded(self, db_session):
        """Audit events must persist to the audit log table."""
        from sqlalchemy import select
        from aureum_core.storage.database import AuditLogRecord

        logger = AuditLogger(db_session)
        await logger.record_event(
            event_type="TEST_EVENT",
            actor="test-actor",
            entity_type="ACCOUNT",
            entity_id="acct-001",
            payload={"key": "value"},
        )
        await db_session.flush()

        stmt = select(AuditLogRecord).where(AuditLogRecord.event_type == "TEST_EVENT")
        result = await db_session.execute(stmt)
        record = result.scalar_one_or_none()

        assert record is not None
        assert record.actor == "test-actor"
        assert record.entity_id == "acct-001"
        assert record.payload == {"key": "value"}

    @pytest.mark.asyncio
    async def test_multiple_audit_events_accumulate(self, db_session):
        """Multiple audit events must all persist (append-only verification)."""
        from sqlalchemy import func, select
        from aureum_core.storage.database import AuditLogRecord

        logger = AuditLogger(db_session)
        for i in range(5):
            await logger.record_event(
                event_type=f"EVENT_{i}",
                actor="actor",
                payload={"index": i},
            )
        await db_session.flush()

        stmt = select(func.count()).select_from(AuditLogRecord)
        result = await db_session.execute(stmt)
        count = result.scalar()
        assert count >= 5


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 8: ACCOUNT TYPE INVARIANTS
# ══════════════════════════════════════════════════════════════════════════════

class TestAccountTypeInvariants:

    def test_asset_normal_balance_is_debit(self):
        """Asset account normal balance must be debit."""
        assert AccountType.ASSET.normal_balance == "debit"

    def test_expense_normal_balance_is_debit(self):
        assert AccountType.EXPENSE.normal_balance == "debit"

    def test_liability_normal_balance_is_credit(self):
        assert AccountType.LIABILITY.normal_balance == "credit"

    def test_equity_normal_balance_is_credit(self):
        assert AccountType.EQUITY.normal_balance == "credit"

    def test_revenue_normal_balance_is_credit(self):
        assert AccountType.REVENUE.normal_balance == "credit"

    @pytest.mark.asyncio
    async def test_provision_all_account_types(self, db_session):
        """All account types must be provisionable."""
        engine = LedgerEngine(db_session)
        for acct_type in AccountType:
            account = await engine.provision_account(
                CreateAccountRequest(
                    owner_id=f"owner-{acct_type.value}",
                    account_type=acct_type,
                    currency="GBP",
                    name=f"Test {acct_type.value}",
                )
            )
            assert account.account_type == acct_type


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 9: IDEMPOTENCY TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestIdempotency:

    @pytest.mark.asyncio
    async def test_idempotency_key_returns_same_result(self, db_session):
        """
        Two submissions with the same idempotency key must return
        the same transaction — no double-processing.
        """
        from aureum_core.transactions.idempotency import IdempotencyEngine
        from aureum_core.storage.database import TransactionRecord

        # Manually insert a committed transaction with an idempotency key
        record = TransactionRecord(
            id="TXN-IDEM-001",
            idempotency_key="unique-key-abc-123",
            status="COMMITTED",
            transaction_type="INTERNAL_TRANSFER",
            initiated_by="TEST",
            metadata_={},
        )
        db_session.add(record)
        await db_session.flush()

        engine = IdempotencyEngine(db_session)
        existing = await engine.check_key("unique-key-abc-123")
        assert existing is not None
        assert existing.id == "TXN-IDEM-001"
        assert await engine.is_duplicate("unique-key-abc-123")

    @pytest.mark.asyncio
    async def test_novel_idempotency_key_returns_none(self, db_session):
        """A never-seen idempotency key must return None."""
        from aureum_core.transactions.idempotency import IdempotencyEngine
        engine = IdempotencyEngine(db_session)
        result = await engine.check_key("never-seen-key-xyz")
        assert result is None


# ══════════════════════════════════════════════════════════════════════════════
# GROUP 10: PAYMENT RAIL TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestPaymentRails:

    def test_faster_payments_gbp_eligible(self):
        from aureum_core.payments.rails.faster_payments import FasterPaymentsRail
        rail = FasterPaymentsRail()
        assert rail.is_eligible(Decimal("1000.00"), "GBP")
        assert not rail.is_eligible(Decimal("1000.00"), "EUR")

    def test_faster_payments_over_limit_ineligible(self):
        from aureum_core.payments.rails.faster_payments import FasterPaymentsRail
        rail = FasterPaymentsRail()
        assert not rail.is_eligible(Decimal("1_500_000.00"), "GBP")

    def test_sepa_eur_eligible(self):
        from aureum_core.payments.rails.sepa import SEPARail
        rail = SEPARail()
        assert rail.is_eligible(Decimal("5000.00"), "EUR")
        assert not rail.is_eligible(Decimal("5000.00"), "GBP")

    def test_sepa_instant_threshold(self):
        from aureum_core.payments.rails.sepa import SEPARail
        rail = SEPARail()
        assert rail.is_instant_eligible(Decimal("50_000.00"))
        assert not rail.is_instant_eligible(Decimal("150_000.00"))

    def test_swift_accepts_any_currency(self):
        from aureum_core.payments.rails.swift import SWIFTRail
        rail = SWIFTRail()
        assert rail.is_eligible(Decimal("500.00"), "JPY")
        assert rail.is_eligible(Decimal("10.00"), "CAD")

    def test_gateway_selects_fps_for_domestic_gbp(self):
        from aureum_core.payments.payment_gateway import PaymentGateway, PaymentRailIdentifier
        gw = PaymentGateway()
        rail = gw.select_rail(Decimal("500.00"), "GBP", is_internal=False, destination_country="GB")
        assert rail == PaymentRailIdentifier.FASTER_PAYMENTS

    def test_gateway_selects_sepa_for_eur(self):
        from aureum_core.payments.payment_gateway import PaymentGateway, PaymentRailIdentifier
        gw = PaymentGateway()
        rail = gw.select_rail(Decimal("5000.00"), "EUR", is_internal=False, destination_country="DE")
        assert rail == PaymentRailIdentifier.SEPA

    def test_gateway_selects_swift_for_usd(self):
        from aureum_core.payments.payment_gateway import PaymentGateway, PaymentRailIdentifier
        gw = PaymentGateway()
        rail = gw.select_rail(Decimal("5000.00"), "USD", is_internal=False, destination_country="US")
        assert rail == PaymentRailIdentifier.SWIFT

    def test_gateway_selects_internal_for_internal_flag(self):
        from aureum_core.payments.payment_gateway import PaymentGateway, PaymentRailIdentifier
        gw = PaymentGateway()
        rail = gw.select_rail(Decimal("5000.00"), "GBP", is_internal=True)
        assert rail == PaymentRailIdentifier.INTERNAL

"""
AUREUM CORE — Limit Enforcement Engine
Per-account and velocity-based transaction limit controls.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.storage.database import LedgerEntryRecord
from aureum_core.utils.config import get_config
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("limits")
_config = get_config()


class LimitBreachError(Exception):
    """Raised when a transaction exceeds a configured limit."""


class LimitEnforcementEngine:
    """
    Enforces per-account transaction limits and velocity controls.
    These controls operate independently of AML and fraud detection.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def enforce_velocity(
        self,
        account_id: str,
        amount: Decimal,
        currency: str,
    ) -> None:
        """
        Enforce the daily velocity limit for the account.
        Raises LimitBreachError if the limit would be exceeded.
        """
        if currency != "GBP":
            return  # Velocity limits currently enforced in GBP only

        daily_total = await self._get_daily_debit_total(account_id, currency)
        projected_total = daily_total + amount

        if projected_total > _config.DAILY_VELOCITY_LIMIT_GBP:
            raise LimitBreachError(
                f"Daily velocity limit breach: current daily total {daily_total} GBP + "
                f"requested {amount} GBP = {projected_total} GBP exceeds "
                f"limit of {_config.DAILY_VELOCITY_LIMIT_GBP} GBP"
            )

        _log.audit_event(
            "VELOCITY_CHECK_PASSED",
            actor="SYSTEM",
            details={
                "account_id": account_id,
                "daily_total_gbp": str(daily_total),
                "projected_gbp": str(projected_total),
                "limit_gbp": str(_config.DAILY_VELOCITY_LIMIT_GBP),
            },
        )

    async def _get_daily_debit_total(self, account_id: str, currency: str) -> Decimal:
        """Sum all debit entries for the account since midnight UTC."""
        today_midnight = datetime.now(timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        stmt = select(
            func.coalesce(func.sum(LedgerEntryRecord.amount), Decimal("0"))
        ).where(
            LedgerEntryRecord.account_id == account_id,
            LedgerEntryRecord.direction == "debit",
            LedgerEntryRecord.currency == currency,
            LedgerEntryRecord.posted_at >= today_midnight,
        )
        result = await self._session.execute(stmt)
        total = result.scalar() or Decimal("0")
        return Decimal(str(total))

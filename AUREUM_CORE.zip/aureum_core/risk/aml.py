"""
AUREUM CORE — Anti-Money Laundering Engine
Rule-based AML detection with threshold triggers and suspicious pattern recognition.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.storage.database import LedgerEntryRecord, RiskEventRecord
from aureum_core.utils.config import get_config
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("aml")
_config = get_config()


@dataclass(frozen=True)
class AMLScreeningResult:
    """Result of an AML screening pass."""
    passed: bool
    should_block: bool
    risk_score: int  # 0-100
    triggered_rules: tuple[str, ...]
    reason: str

    @classmethod
    def clear(cls) -> "AMLScreeningResult":
        return cls(passed=True, should_block=False, risk_score=0, triggered_rules=(), reason="")

    @classmethod
    def alert(cls, rules: list[str], block: bool = False, score: int = 50) -> "AMLScreeningResult":
        return cls(
            passed=False,
            should_block=block,
            risk_score=score,
            triggered_rules=tuple(rules),
            reason="; ".join(rules),
        )


class AMLEngine:
    """
    Rule-based Anti-Money Laundering screening engine.

    Rules implemented:
        AML-001: Single transaction threshold (≥ £10,000)
        AML-002: Structuring detection (multiple transactions just below threshold)
        AML-003: High-frequency large transfers
        AML-004: Round-number transaction pattern
        AML-005: 24-hour aggregate threshold
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def screen_transaction(
        self,
        account_id: str,
        amount: Decimal,
        currency: str,
        counterparty_id: str,
    ) -> AMLScreeningResult:
        """Run all AML rules against the pending transaction."""
        triggered_rules: list[str] = []
        should_block = False
        risk_score = 0

        # ── AML-001: Threshold trigger ────────────────────────────────────────
        if currency == "GBP" and amount >= _config.AML_THRESHOLD_GBP:
            triggered_rules.append(
                f"AML-001: Transaction {amount} GBP meets reporting threshold "
                f"{_config.AML_THRESHOLD_GBP} GBP"
            )
            risk_score = max(risk_score, 40)

        # ── AML-002: Structuring detection ────────────────────────────────────
        structuring_detected = await self._detect_structuring(account_id, amount, currency)
        if structuring_detected:
            triggered_rules.append(
                "AML-002: Structuring pattern detected — multiple sub-threshold transactions"
            )
            risk_score = max(risk_score, 75)
            should_block = True

        # ── AML-004: Round number pattern ─────────────────────────────────────
        if self._is_suspicious_round_number(amount) and amount >= Decimal("5000"):
            triggered_rules.append(
                f"AML-004: Suspiciously round transaction amount: {amount}"
            )
            risk_score = max(risk_score, 20)

        # ── AML-005: 24-hour aggregate ────────────────────────────────────────
        daily_total = await self._get_daily_aggregate(account_id, currency)
        if currency == "GBP" and (daily_total + amount) >= (
            _config.AML_THRESHOLD_GBP * Decimal("5")
        ):
            triggered_rules.append(
                f"AML-005: 24h aggregate {daily_total + amount} GBP exceeds "
                f"enhanced monitoring threshold"
            )
            risk_score = max(risk_score, 60)

        if triggered_rules:
            await self._record_aml_event(
                account_id=account_id,
                rules=triggered_rules,
                should_block=should_block,
                risk_score=risk_score,
                amount=amount,
                currency=currency,
            )
            return AMLScreeningResult.alert(triggered_rules, block=should_block, score=risk_score)

        return AMLScreeningResult.clear()

    async def _detect_structuring(
        self, account_id: str, amount: Decimal, currency: str
    ) -> bool:
        """
        Detect structuring: multiple transactions just below the reporting threshold
        within a 24-hour window (indicative of deliberate evasion).
        """
        if amount >= _config.AML_THRESHOLD_GBP:
            return False

        threshold_90pct = _config.AML_THRESHOLD_GBP * Decimal("0.90")
        if amount < threshold_90pct:
            return False

        # Count transactions in the last 24 hours in the 90–100% threshold band
        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        stmt = (
            select(func.count())
            .select_from(LedgerEntryRecord)
            .where(
                LedgerEntryRecord.account_id == account_id,
                LedgerEntryRecord.direction == "debit",
                LedgerEntryRecord.amount >= threshold_90pct,
                LedgerEntryRecord.amount < _config.AML_THRESHOLD_GBP,
                LedgerEntryRecord.posted_at >= cutoff,
            )
        )
        result = await self._session.execute(stmt)
        count = result.scalar() or 0
        return count >= 2  # 3 or more including current transaction

    async def _get_daily_aggregate(self, account_id: str, currency: str) -> Decimal:
        """Sum all debit entries for the account in the past 24 hours."""
        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        stmt = select(func.coalesce(func.sum(LedgerEntryRecord.amount), Decimal("0"))).where(
            LedgerEntryRecord.account_id == account_id,
            LedgerEntryRecord.direction == "debit",
            LedgerEntryRecord.currency == currency,
            LedgerEntryRecord.posted_at >= cutoff,
        )
        result = await self._session.execute(stmt)
        total = result.scalar() or Decimal("0")
        return Decimal(str(total))

    def _is_suspicious_round_number(self, amount: Decimal) -> bool:
        """Detect suspiciously round amounts: e.g. 10000, 50000, 100000."""
        for divisor in (Decimal("100000"), Decimal("50000"), Decimal("10000"), Decimal("5000")):
            if amount % divisor == 0:
                return True
        return False

    async def _record_aml_event(
        self,
        account_id: str,
        rules: list[str],
        should_block: bool,
        risk_score: int,
        amount: Decimal,
        currency: str,
    ) -> None:
        severity = "CRITICAL" if should_block else ("HIGH" if risk_score >= 60 else "MEDIUM")
        record = RiskEventRecord(
            event_class="AML_ALERT",
            severity=severity,
            account_id=account_id,
            description="; ".join(rules),
            payload={
                "rules": rules,
                "risk_score": risk_score,
                "blocked": should_block,
                "amount": str(amount),
                "currency": currency,
            },
        )
        self._session.add(record)
        _log.risk_event("AML_ALERT", account_id, {"rules": rules, "blocked": should_block})

"""
AUREUM CORE — Fraud Detection Engine
Velocity-based and pattern-based fraud identification.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.storage.database import LedgerEntryRecord, RiskEventRecord
from aureum_core.utils.config import get_config
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("fraud")
_config = get_config()


@dataclass(frozen=True)
class FraudAssessmentResult:
    """Outcome of a fraud assessment pass."""
    passed: bool
    should_block: bool
    fraud_score: int  # 0–100
    triggered_signals: tuple[str, ...]
    reason: str

    @classmethod
    def clear(cls) -> "FraudAssessmentResult":
        return cls(passed=True, should_block=False, fraud_score=0, triggered_signals=(), reason="")

    @classmethod
    def flag(cls, signals: list[str], block: bool = False, score: int = 50) -> "FraudAssessmentResult":
        return cls(
            passed=False,
            should_block=block,
            fraud_score=score,
            triggered_signals=tuple(signals),
            reason="; ".join(signals),
        )


class FraudDetectionEngine:
    """
    Multi-signal fraud detection engine.

    Signals implemented:
        FRD-001: Velocity breach — too many transactions in short window
        FRD-002: Rapid succession — multiple transactions in seconds
        FRD-003: Amount anomaly — transaction significantly exceeds historical average
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def assess(
        self,
        account_id: str,
        amount: Decimal,
        currency: str,
    ) -> FraudAssessmentResult:
        """Assess a pending transaction for fraud signals."""
        signals: list[str] = []
        should_block = False
        fraud_score = 0

        # ── FRD-001: Velocity Breach ──────────────────────────────────────────
        velocity_count = await self._get_velocity_count(account_id)
        if velocity_count >= _config.FRAUD_VELOCITY_MAX_TRANSACTIONS:
            signals.append(
                f"FRD-001: Velocity breach — {velocity_count} transactions in "
                f"{_config.FRAUD_VELOCITY_WINDOW_SECONDS}s window "
                f"(limit: {_config.FRAUD_VELOCITY_MAX_TRANSACTIONS})"
            )
            fraud_score = max(fraud_score, 80)
            should_block = True

        # ── FRD-002: Rapid Succession ─────────────────────────────────────────
        rapid_count = await self._get_rapid_succession_count(account_id)
        if rapid_count >= _config.FRAUD_RAPID_SUCCESSION_THRESHOLD:
            signals.append(
                f"FRD-002: Rapid succession detected — {rapid_count} transactions "
                f"within 30 seconds"
            )
            fraud_score = max(fraud_score, 70)
            should_block = True

        # ── FRD-003: Amount Anomaly ───────────────────────────────────────────
        anomaly = await self._detect_amount_anomaly(account_id, amount, currency)
        if anomaly:
            signals.append(
                f"FRD-003: Amount anomaly — {amount} {currency} is "
                f"significantly above account history"
            )
            fraud_score = max(fraud_score, 55)

        if signals:
            await self._record_fraud_event(account_id, signals, should_block, fraud_score, amount)
            return FraudAssessmentResult.flag(signals, block=should_block, score=fraud_score)

        return FraudAssessmentResult.clear()

    async def _get_velocity_count(self, account_id: str) -> int:
        """Count debit entries within the velocity window."""
        cutoff = datetime.now(timezone.utc) - timedelta(
            seconds=_config.FRAUD_VELOCITY_WINDOW_SECONDS
        )
        stmt = select(func.count()).select_from(LedgerEntryRecord).where(
            LedgerEntryRecord.account_id == account_id,
            LedgerEntryRecord.direction == "debit",
            LedgerEntryRecord.posted_at >= cutoff,
        )
        result = await self._session.execute(stmt)
        return result.scalar() or 0

    async def _get_rapid_succession_count(self, account_id: str) -> int:
        """Count debit entries within the last 30 seconds."""
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=30)
        stmt = select(func.count()).select_from(LedgerEntryRecord).where(
            LedgerEntryRecord.account_id == account_id,
            LedgerEntryRecord.direction == "debit",
            LedgerEntryRecord.posted_at >= cutoff,
        )
        result = await self._session.execute(stmt)
        return result.scalar() or 0

    async def _detect_amount_anomaly(
        self, account_id: str, amount: Decimal, currency: str
    ) -> bool:
        """
        Flag if current transaction is > 10x the 30-day average transaction amount.
        Only triggers if there is sufficient history (> 5 transactions).
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)
        stmt = select(
            func.count().label("tx_count"),
            func.avg(LedgerEntryRecord.amount).label("avg_amount"),
        ).where(
            LedgerEntryRecord.account_id == account_id,
            LedgerEntryRecord.direction == "debit",
            LedgerEntryRecord.currency == currency,
            LedgerEntryRecord.posted_at >= cutoff,
        )
        result = await self._session.execute(stmt)
        row = result.one()

        if row.tx_count < 5 or row.avg_amount is None:
            return False

        avg = Decimal(str(row.avg_amount))
        return avg > Decimal("0") and amount > (avg * Decimal("10"))

    async def _record_fraud_event(
        self,
        account_id: str,
        signals: list[str],
        should_block: bool,
        fraud_score: int,
        amount: Decimal,
    ) -> None:
        severity = "CRITICAL" if should_block else "HIGH"
        record = RiskEventRecord(
            event_class="FRAUD_ALERT",
            severity=severity,
            account_id=account_id,
            description="; ".join(signals),
            payload={"signals": signals, "fraud_score": fraud_score, "blocked": should_block},
        )
        self._session.add(record)
        _log.risk_event("FRAUD_ALERT", account_id, {"signals": signals, "blocked": should_block})

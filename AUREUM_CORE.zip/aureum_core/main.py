"""
AUREUM CORE — Application Entrypoint
Sovereign-grade core banking system runtime initialisation.
"""
from __future__ import annotations

import sys
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from aureum_core.api.routes import router
from aureum_core.storage.database import build_engine, build_session_factory, create_all_tables
from aureum_core.storage.migrations import apply_ddl_supplements
from aureum_core.utils.config import get_config
from aureum_core.utils.logging import configure_logging, get_logger

_config = get_config()
_log = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application lifespan handler.
    Initialises storage and applies schema supplements on startup.
    """
    configure_logging()
    _log.info("AUREUM_CORE_STARTING", institution=_config.INSTITUTION_NAME)

    engine = build_engine()
    build_session_factory(engine)

    try:
        await create_all_tables()
        await apply_ddl_supplements(engine)
        _log.info("SCHEMA_READY", message="Database schema initialised")
    except Exception as exc:
        _log.warning(
            "SCHEMA_INIT_SKIPPED",
            reason=str(exc),
            message="Proceeding — ensure PostgreSQL is available for full operation",
        )

    _log.info("AUREUM_CORE_READY", host=_config.API_HOST, port=_config.API_PORT)
    yield

    _log.info("AUREUM_CORE_SHUTDOWN")
    await engine.dispose()


def create_application() -> FastAPI:
    """Construct and configure the AUREUM CORE FastAPI application."""
    app = FastAPI(
        title="AUREUM CORE",
        description=(
            "Autonomous Unified Runtime for Enterprise Monetary Systems — "
            "a production-grade core banking engine with double-entry ledger accounting, "
            "transaction processing, payments infrastructure, and risk compliance."
        ),
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # ── CORS ──────────────────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Restrict in production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Exception Handlers ────────────────────────────────────────────────────
    @app.exception_handler(Exception)
    async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        _log.error("UNHANDLED_EXCEPTION", error=str(exc), path=str(request.url))
        return JSONResponse(
            status_code=500,
            content={"error": "INTERNAL_ERROR", "detail": "An unexpected error occurred"},
        )

    # ── Routes ────────────────────────────────────────────────────────────────
    app.include_router(router, prefix="/v1")

    return app


application = create_application()


if __name__ == "__main__":
    uvicorn.run(
        "aureum_core.main:application",
        host=_config.API_HOST,
        port=_config.API_PORT,
        reload=_config.API_DEBUG,
        log_level="info",
    )

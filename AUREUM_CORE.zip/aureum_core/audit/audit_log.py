"""
AUREUM CORE — Audit Logger
Immutable append-only event log for all system actions.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.storage.database import AuditLogRecord
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("audit")


class AuditLogger:
    """
    Records all material system events to the immutable audit log.
    Every write is append-only — no audit record may be modified or deleted.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def record_event(
        self,
        event_type: str,
        actor: str,
        entity_type: str | None = None,
        entity_id: str | None = None,
        payload: dict[str, Any] | None = None,
        ip_address: str | None = None,
        session_id: str | None = None,
    ) -> AuditLogRecord:
        """Append an immutable audit event to the log."""
        record = AuditLogRecord(
            event_type=event_type,
            actor=actor,
            entity_type=entity_type,
            entity_id=entity_id,
            payload=payload or {},
            ip_address=ip_address,
            session_id=session_id,
        )
        self._session.add(record)
        await self._session.flush()

        _log.audit_event(
            event_type,
            actor=actor,
            details={
                "entity_type": entity_type,
                "entity_id": entity_id,
            },
        )
        return record

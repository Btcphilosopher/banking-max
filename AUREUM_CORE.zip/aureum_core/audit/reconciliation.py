"""
AUREUM CORE — Reconciliation Engine
Ledger consistency verification and mismatch detection.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import case, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from aureum_core.storage.database import AccountRecord, LedgerEntryRecord, TransactionRecord
from aureum_core.utils.logging import FinancialOperationLogger

_log = FinancialOperationLogger("reconciliation")


@dataclass
class ReconciliationReport:
    """Summary of a ledger reconciliation pass."""
    run_at: datetime
    transactions_checked: int
    balanced_transactions: int
    unbalanced_transactions: list[dict[str, Any]] = field(default_factory=list)
    orphaned_entries: list[str] = field(default_factory=list)
    total_system_debit: Decimal = Decimal("0")
    total_system_credit: Decimal = Decimal("0")
    is_consistent: bool = True

    @property
    def system_imbalance(self) -> Decimal:
        return self.total_system_debit - self.total_system_credit

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_at": self.run_at.isoformat(),
            "transactions_checked": self.transactions_checked,
            "balanced_transactions": self.balanced_transactions,
            "unbalanced_count": len(self.unbalanced_transactions),
            "unbalanced_transactions": self.unbalanced_transactions,
            "orphaned_entries": self.orphaned_entries,
            "total_system_debit": str(self.total_system_debit),
            "total_system_credit": str(self.total_system_credit),
            "system_imbalance": str(self.system_imbalance),
            "is_consistent": self.is_consistent,
        }


class ReconciliationEngine:
    """
    Performs systematic verification of ledger integrity.

    Checks:
        1. Every committed transaction has balanced entries
        2. No orphaned ledger entries (entries without a transaction)
        3. System-wide debit/credit totals are equal
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def run_full_reconciliation(self) -> ReconciliationReport:
        """Execute a complete ledger reconciliation pass."""
        report = ReconciliationReport(run_at=datetime.now(timezone.utc), transactions_checked=0, balanced_transactions=0)

        _log.audit_event("RECONCILIATION_STARTED", actor="SYSTEM", details={})

        # ── Check 1: Per-transaction balance ──────────────────────────────────
        stmt = select(
            LedgerEntryRecord.transaction_id,
            func.sum(
                case(
                    (LedgerEntryRecord.direction == "debit", LedgerEntryRecord.amount),
                    else_=Decimal("0"),
                )
            ).label("total_debits"),
            func.sum(
                case(
                    (LedgerEntryRecord.direction == "credit", LedgerEntryRecord.amount),
                    else_=Decimal("0"),
                )
            ).label("total_credits"),
        ).group_by(LedgerEntryRecord.transaction_id)

        result = await self._session.execute(stmt)
        rows = result.all()

        report.transactions_checked = len(rows)

        for row in rows:
            debits = Decimal(str(row.total_debits))
            credits = Decimal(str(row.total_credits))

            if debits == credits:
                report.balanced_transactions += 1
            else:
                report.is_consistent = False
                report.unbalanced_transactions.append({
                    "transaction_id": row.transaction_id,
                    "total_debits": str(debits),
                    "total_credits": str(credits),
                    "imbalance": str(debits - credits),
                })

        # ── Check 2: System-wide totals ───────────────────────────────────────
        totals_stmt = select(
            func.coalesce(
                func.sum(LedgerEntryRecord.amount).filter(LedgerEntryRecord.direction == "debit"),
                Decimal("0"),
            ).label("system_debits"),
            func.coalesce(
                func.sum(LedgerEntryRecord.amount).filter(LedgerEntryRecord.direction == "credit"),
                Decimal("0"),
            ).label("system_credits"),
        )
        totals_result = await self._session.execute(totals_stmt)
        totals_row = totals_result.one()

        report.total_system_debit = Decimal(str(totals_row.system_debits))
        report.total_system_credit = Decimal(str(totals_row.system_credits))

        if report.total_system_debit != report.total_system_credit:
            report.is_consistent = False

        # ── Check 3: Orphaned entries ─────────────────────────────────────────
        orphan_stmt = select(LedgerEntryRecord.transaction_id.distinct()).where(
            ~LedgerEntryRecord.transaction_id.in_(
                select(TransactionRecord.id)
            )
        )
        orphan_result = await self._session.execute(orphan_stmt)
        orphaned = [row[0] for row in orphan_result.all()]
        report.orphaned_entries = orphaned
        if orphaned:
            report.is_consistent = False

        _log.audit_event(
            "RECONCILIATION_COMPLETED",
            actor="SYSTEM",
            details={
                "is_consistent": report.is_consistent,
                "transactions_checked": report.transactions_checked,
                "unbalanced_count": len(report.unbalanced_transactions),
            },
        )

        return report
